<?php
/*
 Name:  Footer style 03
 */
?>
<footer class="footer style-03">
	<div class="container">
		<?php the_content(); ?>
	</div>
</footer>
