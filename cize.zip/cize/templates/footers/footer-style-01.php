<?php
/*
 Name:  Footer style 01
 */
?>
<footer class="footer style-01">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>
