<?php
$post_format = get_post_format();
do_action('cize_before_single_blog_content');
?>
    <article <?php post_class('post-item post-single'); ?>>
        <div class="single-post-thumb">
            <?php cize_post_format(); ?>
        </div>
        <div class="single-post-info">
            <div class="post-meta">
                <?php
                cize_post_date();
                cize_post_comment();
                ?>
            </div>
            <?php
            cize_post_title();
            cize_post_category();
            ?>
        </div>
        <?php
        cize_post_full_content();
        ?>
        <?php
        cize_post_tags();
        cize_share_button();
        ?>
    </article>
<?php
do_action('cize_after_single_blog_content');