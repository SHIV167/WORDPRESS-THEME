<?php get_header();

$enable_single_product_mobile = cize_get_option( 'enable_single_product_mobile', true );

/* Shop layout */
$cize_woo_shop_layout  = cize_get_option( 'sidebar_shop_page_position', 'left' );
$cize_woo_shop_sidebar = cize_get_option( 'shop_page_sidebar', 'shop-widget-area' );
$filter_shop_page      = cize_get_option( 'filter_shop_page', 'top_sidebar' );
if ( is_product() ) {
	$cize_woo_shop_layout  = cize_get_option( 'sidebar_product_position', 'left' );
	$cize_woo_shop_sidebar = cize_get_option( 'single_product_sidebar', 'product-widget-area' );
}

// Always full width on real mobile
if ( $enable_single_product_mobile && cize_is_mobile() ) {
	$cize_woo_shop_layout = 'full';
}

if ( ! is_active_sidebar( $cize_woo_shop_sidebar ) ) {
	$cize_woo_shop_layout = 'full';
}

/* Main container class */
$main_container_class   = array();
$main_container_class[] = 'main-container shop-page';
$page_banner_type       = cize_get_option( 'shop_banner_type', 'no_background' );

if ( is_shop() || is_product_category() || is_product_tag() ) {
	if ( $page_banner_type == 'has_background' ) {
		$main_container_class[] = 'shop-bg';
	}
}

if ( $cize_woo_shop_layout == 'full' ) {
	$main_container_class[] = 'no-sidebar';
} else {
	$main_container_class[] = $cize_woo_shop_layout . '-sidebar';
}

/* Setting single product */
$main_content_class   = array();
$main_content_class[] = 'main-content';
$main_widget_class    = array();
$main_widget_class[]  = 'widget-shop-wrap';
$main_product_wrap    = array();
$main_product_wrap[]  = 'main-product-wrap';

if ( $filter_shop_page == 'drawer_sidebar' ) {
	$main_widget_class[] = 'drawer_sidebar_elem';
	$main_product_wrap[] = 'drawer_sidebar_elem';
}

if ( $cize_woo_shop_layout == 'full' ) {
	$main_content_class[] = 'col-sm-12';
} else {
	$main_content_class[] = 'col-lg-9 col-md-8 col-sm-12 has-sidebar';
}

$slidebar_class   = array();
$slidebar_class[] = 'sidebar';
if ( ( $cize_woo_shop_layout == 'left' ) || ( $cize_woo_shop_layout == 'right' ) ) {
	$slidebar_class[] = 'col-lg-3 col-md-4 col-sm-12 sidebar-' . $cize_woo_shop_layout;
}

$list_categories       = cize_get_option( 'panel-categories', array() );
$product_inner_class[] = 'cize-single-container';
$enable_extend_sidebar = cize_get_option( 'enable_extend_single_product', false );
$product_style         = cize_get_option( 'cize_woo_single_product_layout', 'default' );
$product_meta          = get_post_meta( get_the_ID(), '_custom_product_metabox_theme_options', true );
if ( isset( $product_meta['product_style'] ) ) {
	$product_style = $product_meta['product_style'];
}
if ( $enable_extend_sidebar ) {
	$product_inner_class[] = 'container-extend';
}
if ( $product_style == 'slider_large' ) {
	$product_inner_class[] = 'container-extend-large';
}
?>
    <div class="<?php echo esc_attr( implode( ' ', $main_container_class ) ); ?>">
		<?php if ( ( is_shop() || is_product_category() || is_product_tag() ) && $list_categories ): ?>
			<?php
			$queried_obj = get_queried_object();
			$cur_term_id = isset( $queried_obj->term_id ) ? $queried_obj->term_id : 0;
			?>
            <div class="panel-categories">
                <div class="panel-categories-inner">
					<?php foreach ( $list_categories as $list_category ) {
						$product_term = get_term( $list_category, 'product_cat' );
						if ( ! is_wp_error( $product_term ) ) {
							if ( isset( $product_term ) ) {
								$cat_link   = get_term_link( $product_term->term_id, 'product_cat' );
								$term_class = $cur_term_id == $product_term->term_id ? 'product-cat-link current-product-cat' : 'product-cat-link';
								?>
                                <a data-slug="<?php echo esc_attr( $product_term->slug ); ?>"
                                   href="<?php echo esc_url( $cat_link ); ?>"
                                   class="<?php echo esc_attr( $term_class ); ?>"><?php echo esc_attr( $product_term->name ); ?></a>
								<?php
							}
						}
					}; ?>
                </div>
            </div>
		<?php endif; ?>
		<?php if ( ! is_single() ) { ?>
		<?php }else{ ?>
        <div class="<?php echo esc_attr( implode( ' ', $product_inner_class ) ); ?>">
			<?php }; ?>
            <div class="container">
                <div class="row <?php echo esc_attr( $filter_shop_page ); ?>">
                    <div class="<?php echo esc_attr( implode( ' ', $main_content_class ) ); ?>">
                        <div class="<?php echo esc_attr( implode( ' ', $main_product_wrap ) ); ?>">
							<?php
							/**
							 * cize_woocommerce_before_main_content hook
							 */
							do_action( 'cize_woocommerce_before_main_content' );
							?>
							<?php
							/**
							 * cize_before_shop_loop hook.
							 *
							 * @hooked cize_shop_top_control - 10
							 */
							do_action( 'cize_before_shop_loop' );
							?>
                            <div class="main-product">
								<?php
								
								if ( have_posts() ) {
									woocommerce_content();
								}
								
								?>
                            </div> <!-- End .main-product-->
                        </div>
                    </div>
					<?php if ( ! is_product() && ( $cize_woo_shop_layout == 'full' ) && ( $filter_shop_page == 'drawer_sidebar' || $filter_shop_page == 'offcanvas_sidebar' ) ): ?>
						<?php if ( is_active_sidebar( $cize_woo_shop_sidebar ) ) : ?>
                            <div class="<?php echo esc_attr( implode( ' ', $main_widget_class ) ); ?>">
                                <div class="widget-shop-inner">
                                    <div id="widget-area" class="widget-area shop-sidebar">
										<?php dynamic_sidebar( $cize_woo_shop_sidebar ); ?>
                                    </div><!-- .widget-area -->
                                </div>
                            </div>
                            <div class="main-widget-overlay"></div>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( ( $cize_woo_shop_layout == 'left' ) || ( $cize_woo_shop_layout == 'right' ) ): ?>
                        <div class="<?php echo esc_attr( implode( ' ', $slidebar_class ) ); ?>">
							<?php if ( is_active_sidebar( $cize_woo_shop_sidebar ) ) : ?>
                                <div id="widget-area" class="widget-area shop-sidebar">
									<?php dynamic_sidebar( $cize_woo_shop_sidebar ); ?>
                                </div><!-- .widget-area -->
							<?php endif; ?>
                        </div>
					<?php endif; ?>
                </div>
            </div>
			<?php if ( ! is_single() ) { ?>
			<?php }else{ ?>
        </div>
	<?php }; ?>
    </div>
<?php get_footer(); ?>