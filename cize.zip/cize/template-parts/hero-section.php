<?php

/*
 * Header banner (Hero section)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( is_single() ) {
	return;
}

$single_id            = cize_get_single_page_id();
$enable_custom_banner = false;
$meta_data            = get_post_meta( $single_id, '_custom_metabox_theme_options', true );
if ( isset( $meta_data['enable_custom_banner'] ) ) {
	$enable_custom_banner = $meta_data['enable_custom_banner'];
	// Check request hero_section_type for custom banner
	if ( isset( $_GET['hero_section_type'] ) ) {
		$meta_data['hero_section_type'] = $_GET['hero_section_type'];
	}
}

if ( $enable_custom_banner ) {
	$enable_header_mobile                = cize_get_option( 'enable_header_mobile', false );
	$show_hero_section                   = true;
	
	// Check hero section on mobile is enabled or disabled
	if ( $enable_header_mobile && cize_is_mobile() ) {
		$enable_hero_section_mobile = isset( $meta_data['show_hero_section_on_header_mobile'] ) ? $meta_data['show_hero_section_on_header_mobile'] : false;
		if ( ! $enable_hero_section_mobile ) {
			$show_hero_section = false;
		}
	}
	
	if ( ! $show_hero_section ) {
		return;
	}
	
	switch ( $meta_data['hero_section_type'] ) {
		case 'rev_background':
			if ( $meta_data['cize_metabox_header_rev_slide'] != '' && shortcode_exists( 'rev_slider' ) ) {
				?>
                <div class="slider-rev-wrap">
					<?php echo do_shortcode( '[rev_slider alias="' . esc_attr( $meta_data['cize_metabox_header_rev_slide'] ) . '"][/rev_slider]' ); ?>
                </div>
				<?php
			}
			break;
		case 'has_background':
		case 'no_background' :
			$page_banner_type = $meta_data['hero_section_type'];
			$page_img_banner             = $meta_data['bg_banner_page'];
			$cize_page_heading_height    = $meta_data['page_height_banner'];
			$cize_page_banner_breadcrumb = $meta_data['page_banner_breadcrumb'];
			$is_banner_full_width        = $meta_data['page_banner_full_width'];
			$css                         = '';
			if ( $page_banner_type == 'has_background' ) {
				if ( ( $page_img_banner['image'] ) !== '' ) {
					$css .= 'background-image:  url("' . esc_url( $page_img_banner['image'] ) . '");';
				} else {
					$css .= 'background-image:  url("' . get_template_directory_uri() . '/assets/images/bn_blog.jpg' . '");';
					$css .= 'background-size: cover;';
				}
				$css .= 'background-repeat: ' . esc_attr( $page_img_banner['repeat'] ) . ';';
				$css .= 'background-position:   ' . esc_attr( $page_img_banner['position'] ) . ';';
				$css .= 'background-attachment: ' . esc_attr( $page_img_banner['attachment'] ) . ';';
				$css .= 'background-size:   ' . esc_attr( $page_img_banner['size'] ) . ';';
				$css .= 'background-color:  ' . esc_attr( $page_img_banner['color'] ) . ';';
			}
			$css .= 'min-height:' . esc_attr( $cize_page_heading_height ) . 'px;';
			
			if ( ! $is_banner_full_width ) { ?>
                <div class="container">
                <div class="row">
			<?php } ?>
            <div class="rev_slider banner-page <?php echo esc_attr( $page_banner_type ); ?>"
                 style='<?php echo esc_attr( $css ); ?>'>
                <div class="content-banner">
                    <div class="container">
						<?php if ( ! is_front_page() ) { ?>
                            <h2 class="title-page page-title">
								<?php
                                if ( class_exists( 'WooCommerce' ) ) {
                                    if ( is_woocommerce() ) {
                                        echo woocommerce_page_title( false );
                                    } else {
                                        if ( is_home() ) :
                                            if ( is_front_page() ):
                                                esc_html_e( 'Latest Posts', 'casano' );
                                            else:
                                                single_post_title();
                                            endif;
                                        elseif ( is_page() ):
                                            single_post_title();
                                        elseif ( is_search() ):
                                            echo sprintf( __( 'Search Results for: %s', 'casano' ), '<span>' . get_search_query() . '</span>' );
                                        else:
                                            the_archive_title();
                                        endif;
                                    }
                                } else {
                                    if ( is_home() ) :
                                        if ( is_front_page() ):
                                            esc_html_e( 'Latest Posts', 'casano' );
                                        else:
                                            single_post_title();
                                        endif;
                                    elseif ( is_page() ):
                                        single_post_title();
                                    elseif ( is_search() ):
                                        echo sprintf( __( 'Search Results for: %s', 'casano' ), '<span>' . get_search_query() . '</span>' );
                                    else:
                                        the_archive_title();
                                    endif;
                                } ?>
                            </h2>
						<?php } ?>
						<?php if ( ! is_front_page() && $cize_page_banner_breadcrumb ) {
							get_template_part( 'template-parts/part', 'breadcrumb' );
						}; ?>
                    </div>
                </div>
            </div>
			<?php
			if ( ! $is_banner_full_width ) { ?>
                </div>
                </div>
			<?php }
			break;
		case 'disable':
			break;
		default:
			break;
	}
} else {
	$default_page_banner_height = 0;
	if ( is_front_page() && is_home() ) {
		$default_page_banner_height = 0;
	}
	
	$page_banner_type     = cize_get_option( 'page_banner_type', 'no_background' );
	$page_banner_image    = cize_get_option( 'page_banner_image' );
	$is_banner_full_width = cize_get_option( 'page_banner_full_width', true );
	$page_banner_height   = cize_get_option( 'page_height_banner', $default_page_banner_height );
	
	if ( class_exists( 'WooCommerce' ) ) {
		if ( is_shop() || is_product_category() || is_product_tag() ) {
			$page_banner_type     = cize_get_option( 'shop_banner_type', 'no_background' );
			$page_banner_image    = cize_get_option( 'shop_banner_image' );
			$is_banner_full_width = true;
			$page_banner_height   = cize_get_option( 'shop_banner_height', 0 );
		}
	}
	
	$css = '';
	if ( $page_banner_type == 'has_background' ) {
		if ( ( $page_banner_image['image'] ) !== '' ) {
			$css .= 'background-image:  url("' . esc_url( $page_banner_image['image'] ) . '");';
		} else {
			$css .= 'background-image:  url("' . get_template_directory_uri() . '/assets/images/bn_blog.jpg' . '");';
			$css .= 'background-size: cover;';
		}
		$css .= 'background-repeat: ' . esc_attr( $page_banner_image['repeat'] ) . ';';
		$css .= 'background-position:   ' . esc_attr( $page_banner_image['position'] ) . ';';
		$css .= 'background-attachment: ' . esc_attr( $page_banner_image['attachment'] ) . ';';
		$css .= 'background-size:   ' . esc_attr( $page_banner_image['size'] ) . ';';
		$css .= 'background-color:  ' . esc_attr( $page_banner_image['color'] ) . ';';
	}
	$css .= 'min-height:' . intval( $page_banner_height ) . 'px;';
	
	if ( ! $is_banner_full_width ) { ?>
        <div class="container">
        <div class="row">
	<?php } ?>
    <div class="banner-page hero-banner-page <?php echo esc_attr( $page_banner_type ); ?>"
         style='<?php echo esc_attr( $css ); ?>'>
        <div class="content-banner">
            <div class="container">
				<?php if ( ! is_front_page() ) { ?>
                    <h2 class="title-page page-title">
						<?php
						if ( class_exists( 'WooCommerce' ) ) {
							if ( is_woocommerce() ) {
								echo woocommerce_page_title( false );
							} else {
								if ( is_home() ) :
									if ( is_front_page() ):
										esc_html_e( 'Latest Posts', 'casano' );
									else:
										single_post_title();
									endif;
                                elseif ( is_page() ):
									single_post_title();
                                elseif ( is_search() ):
									echo sprintf( __( 'Search Results for: %s', 'casano' ), '<span>' . get_search_query() . '</span>' );
								else:
									the_archive_title();
								endif;
							}
						} else {
							if ( is_home() ) :
								if ( is_front_page() ):
									esc_html_e( 'Latest Posts', 'casano' );
								else:
									single_post_title();
								endif;
                            elseif ( is_page() ):
								single_post_title();
                            elseif ( is_search() ):
								echo sprintf( __( 'Search Results for: %s', 'casano' ), '<span>' . get_search_query() . '</span>' );
							else:
								the_archive_title();
							endif;
						} ?>
                    </h2>
				<?php } else { ?>
                    <h2 class="title-page page-title">
                        <?php if ( is_home() ) :
                            if ( is_front_page() ):
                                echo esc_html__( 'Latest Posts', 'casano' );
                            else:
                                single_post_title();
                            endif;
                        elseif ( is_page() ):
                            single_post_title();
                        elseif ( is_search() ):
                            echo sprintf( __( 'Search Results for: %s', 'casano' ), '<span>' . get_search_query() . '</span>' );
                        else:
                            the_archive_title();
                        endif;?>
                    </h2>
                <?php } ?>
				<?php get_template_part( 'template-parts/part', 'breadcrumb' ); ?>
            </div>
        </div>
    </div>
	<?php
	if ( ! $is_banner_full_width ) { ?>
        </div>
        </div>
	<?php }
}

