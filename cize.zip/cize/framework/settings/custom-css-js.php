<?php

if ( ! function_exists( 'cize_custom_css' ) ) {
	function cize_custom_css() {
		$css = '';
		$css .= cize_theme_color();
		$css .= cize_vc_custom_css_footer();
		wp_enqueue_style( 'cize_custom_css', get_theme_file_uri( '/assets/css/customs.css' ), array(), '1.0' );
		wp_add_inline_style( 'cize_custom_css', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'cize_custom_css', 999 );

if ( ! function_exists( 'cize_theme_color' ) ) {
	function cize_theme_color() {
		$css = '';
		
		// Typography
		$enable_google_font = cize_get_option( 'enable_google_font', false );
		if ( $enable_google_font ) {
			$body_font = cize_get_option( 'typography_themes' );
			if ( ! empty( $body_font ) ) {
				$typography_themes['family']  = 'Open Sans';
				$typography_themes['variant'] = '400';
				$body_fontsize        = cize_get_option( 'fontsize-body', '15' );
				
				$css .= 'body{';
				$css .= 'font-family: "' . $body_font['family'] . '";';
				if ( '100italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 100;
					font-style: italic;
				';
				} elseif ( '300italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 300;
					font-style: italic;
				';
				} elseif ( '400italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 400;
					font-style: italic;
				';
				} elseif ( '700italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 700;
					font-style: italic;
				';
				} elseif ( '800italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 700;
					font-style: italic;
				';
				} elseif ( '900italic' == $body_font['variant'] ) {
					$css .= '
					font-weight: 900;
					font-style: italic;
				';
				} elseif ( 'regular' == $body_font['variant'] ) {
					$css .= 'font-weight: 400;';
				} elseif ( 'italic' == $body_font['variant'] ) {
					$css .= 'font-style: italic;';
				} else {
					$css .= 'font-weight:' . $body_font['variant'] . ';';
				}
				// Body font size
				if ( $body_fontsize ) {
					$css .= 'font-size:' . esc_attr( $body_fontsize ) . 'px;';
				}
				$css .= '}';
				$css .= 'body
				{
					font-family: "' . $body_font['family'] . '";
				}
			
				';
			}
		}
		
		/* Main color */
		$main_color      = cize_get_option( 'cize_main_color', '#f33c3c' );
		$body_text_color = trim( cize_get_option( 'cize_body_text_color', '' ) );
		$css .= '
		        .cize-newsletter .newsletter-form-wrap button,
                .cize-categories.style-02 .button,
				.post-password-form input[type="submit"]:hover,
                .woocommerce-error .button:hover, .woocommerce-info .button:hover, .woocommerce-message .button:hover,
                .widget_shopping_cart .woocommerce-mini-cart__buttons .button.checkout,
                .widget_shopping_cart .woocommerce-mini-cart__buttons .button:not(.checkout):hover,
                #widget-area .widget .select2-container--default .select2-selection--multiple .select2-selection__choice,
                .woocommerce-widget-layered-nav-dropdown .woocommerce-widget-layered-nav-dropdown__submit:hover,
                .fami-btn:hover,
                .owl-dots .owl-dot.active,
                .owl-dots .owl-dot:hover,
                .search-view,
                .header .cize-minicart .mini-cart-icon .minicart-number,
                .header .minicart-content-inner .minicart-number-items,
                .header-table .header-control-wrap .header-search-box .search-icon,
                .header-color-light .header-table .header-control-wrap .header-search-box .search-icon:hover,
                .datebox span:last-child,
                .comment-form .form-submit #submit:hover,
                .cize-categories.style-04 .cize-category-wrap .category-name:first-child a,
                .cize-categories.style-04 .cize-category-wrap .category-name a:hover,
                .cize-tabs.style-04 .button-tabs:hover,
                .product-item .button-loop-action .add-to-cart:hover,
                .product-item .button-loop-action .yith-wcqv-button:hover,
                .product-item .button-loop-action .yith-wcwl-add-to-wishlist:hover,
                .product-item .button-loop-action .compare-button:hover,
                .product-item .button-loop-action .yith-wcqv-button:hover,
                .cize-products.style-3 .product-title-wrap .button-products:hover,
                .cize-products.style-4 .owl-dots .owl-dot.active,
                .cize-dealproduct.style-01 .product-info .process-valiable .valiable-total .process,
                .cize-search.style-01 .search-fields .search-submit,
                .reset_variations:hover,
                .summary .cart .single_add_to_cart_button:hover,
                .sticky_info_single_product button.cize-single-add-to-cart-btn.btn.button,
                .social-share-product,
                .product-grid-title::before,
                .part-filter-wrap .filter-toggle,
                .part-filter-wrap .filter-toggle-button,
                a.backtotop,
                .widget_categories ul li a:hover::before,
                .widget_search .searchform button:hover,
                .cize_socials_list_widget .social::before,
                .cize_newsletter_widget button,
                .loadmore-product:hover span:first-child,
                span.prdctfltr_title_selected,
                span.prdctfltr_reset-clone:hover,
                .onsale,
                 #yith-wcwl-popup-message,
                .return-to-shop .button:hover,
                 body .woocommerce table.shop_table .product-add-to-cart .add_to_cart:hover,
                .actions-btn .shopping:hover,
                .actions .coupon .button:hover,
                .wc-proceed-to-checkout .checkout-button:hover,
                .woocommerce-MyAccount-content input.button:hover,
                .track_order .form-tracking .button:hover,
                body.error404 .error-404 .button:hover,
                 #popup-newsletter .newsletter-form-wrap .submit-newsletter:hover,
                .wpcf7-form .wpcf7-submit:hover,
                .cize-socials .socials-inner a::before,
                 .error404 .cize-searchform button:hover,
                .page-404 a.button,
                .cize-content-single-product-mobile .product-mobile-layout .woocommerce-product-gallery .flex-control-nav.flex-control-thumbs li img.flex-active,
                .bestseller-cat-products .block-title > a {
                    background-color: ' . esc_attr( $main_color ) . ';
                }
                a:hover, a:focus, a:active,
                .wcml-dropdown .wcml-cs-submenu li:hover > a,
                .horizon-menu .main-menu .menu-item:hover > a,
                .horizon-menu .main-menu .menu-item .submenu .menu-item:hover > a,
                .horizon-menu .main-menu .menu-item:hover > .toggle-submenu,
                .close-vertical-menu:hover,
                .vertical-menu .main-navigation .main-menu > .menu-item:hover > a,
                .header-search-box > .icons:hover,
                .instant-search-close:hover,
                .instant-search-modal .product-cats label span:hover,
                .instant-search-modal .product-cats label.selected span,
                .currency-language .dropdown .active a,
                header .wcml_currency_switcher li li a:hover,
                .header .cize-minicart:hover .mini-cart-icon,
                .header .minicart-content-inner .close-minicart:hover,
                .header .minicart-items .product-cart .product-remove .remove:hover,
                .header .minicart-content-inner .actions .button:hover,
                .header .to-cart:hover,
                .single-post-info .categories a:hover,
                .filter-button-group .filter-list .blog-filter.active,
                .cize-contact ul > li,
                .cize-custommenu .menu > li > a:hover,
                .cize-categories.style-01 .cize-category-wrap .button,
                .cize-tabs.style-01 .tab-link > li.active,
                .deals-in-wrap .deals-title::before,
                .woocommerce-product-gallery .woocommerce-product-gallery__trigger:hover,
                .woocommerce-product-gallery .flex-control-nav.flex-control-thumbs .slick-arrow,
                .summary .woocommerce-product-rating .woocommerce-review-link:hover,
                .summary .stock.out-of-stock,
                .woocommerce-product-details__short-description li,
                div button.close,
                .product_meta a:hover,
                p.stars:hover a:before,
                p.stars.selected:not(:hover) a:before,
                .total-price-html,
                div.famibt-wrap .famibt-item .famibt-price,
                .famibt-wrap ins,
                .WOOF_Widget .woof_container .icheckbox_flat-purple.checked ~ label,
                .WOOF_Widget .woof_container .iradio_flat-purple.checked ~ label,
                .WOOF_Widget .woof_container li label.hover,
                .WOOF_Widget .woof_container li label.hover,
                .box-mobile-menu .back-menu:hover,
                .box-mobile-menu .close-menu:hover,
                .box-mobile-menu .main-menu .menu-item.active > a,
                .box-mobile-menu .main-menu .menu-item:hover > a,
                .box-mobile-menu .main-menu .menu-item:hover > .toggle-submenu::before,
                nav.woocommerce-breadcrumb a:hover,
                .toolbar-products .category-filter li.active a,
                .toolbar-products .category-filter li a:hover,
                div.prdctfltr_wc.prdctfltr_round .prdctfltr_filter label.prdctfltr_active > span,
                div.prdctfltr_wc.prdctfltr_round .prdctfltr_filter label:hover > span,
                div.prdctfltr_wc.prdctfltr_round .prdctfltr_filter label:hover,
                .prdctfltr_sc.hide-cat-thumbs .product-category h2.woocommerce-loop-category__title:hover,
                .toolbar-products-mobile .cat-item.active, .toolbar-products-mobile .cat-item.active a,
                .real-mobile-toolbar.toolbar-products-shortcode .cat-item.active, .real-mobile-toolbar.toolbar-products-shortcode .cat-item.active a,
                .enable-shop-page-mobile .shop-page a.products-size.products-list.active,
                .enable-shop-page-mobile .woocommerce-page-header ul .line-hover a:hover,
                .enable-shop-page-mobile .woocommerce-page-header ul .line-hover.active a,
                .price ins,
                body .woocommerce table.shop_table tr td.product-remove a:hover,
                .validate-required label::after,
                .woocommerce-MyAccount-navigation > ul li.is-active a {
                    color: ' . esc_attr( $main_color ) . ';
                }
                .header.style-06 .header-table .header-control-wrap .header-search-box .search-icon:hover {
                    color: ' . esc_attr( $main_color ) . ' !important;
                }
                .widget_tag_cloud .tagcloud a:hover,
                .post-item .tags a:hover,
                .cize-share-socials a:hover,
                .cize-tabs.style-02 .tab-link > li.active > a,
                .cize-tabs.style-04 .tab-link > li.active > a,
                .cize-tabs.style-05 .tab-link > li.active > a,
                .cize-tabs.style-02 .tab-link > li > a:hover,
                .cize-tabs.style-04 .tab-link > li > a:hover,
                .cize-tabs.style-05 .tab-link > li > a:hover,
                .summary .compare:hover,
                .woocommerce-cart-form-mobile .actions .actions-btn .shopping:hover {
                    background-color: ' . esc_attr( $main_color ) . ';
                    border-color: ' . esc_attr( $main_color ) . ';
                }
                blockquote, q {
                    border-left: 3px solid ' . esc_attr( $main_color ) . ';
                }
                .banner-page .content-banner .page-title::before { 
                    border: 1px solid ' . esc_attr( $main_color ) . ';
                }
                .instant-search-modal .product-cats label span::before,
                .cize-tabs.style-01 .tab-link > li a::before {
                    border-bottom: 1px solid ' . esc_attr( $main_color ) . ';
                }
                .cize-ripple div,
                .currency-language .wcml-dropdown-click a.wcml-cs-item-toggle:hover::before,
                .currency-language .dropdown > a:hover::before {
                    border-color: ' . esc_attr( $main_color ) . ';
                }
                .currency-language .wcml-dropdown-click a.wcml-cs-item-toggle:hover::after,
                .currency-language .dropdown > a:hover::after {
                    border-color: ' . esc_attr( $main_color ) . ' transparent transparent transparent;
                }
                .header .to-cart::before,
                .blog-grid .title span::before,
                .filter-button-group .filter-list .blog-filter::before {
                    border-bottom: 2px solid ' . esc_attr( $main_color ) . ';
                }
                @media (min-width: 1200px) {
                    .cize-tabs.style-01 .owl-carousel .owl-nav > div:hover {
                        background-color: ' . esc_attr( $main_color ) . ';
                    }
                }
                .cize-tabs.style-03 .tab-link li.active::before {
                    border-bottom: 4px solid ' . esc_attr( $main_color ) . ';
                }
                .cize-title.style-01 .block-title::before,
                .cize-title.style-02 .block-title::before {
                    border-bottom: 1px solid ' . esc_attr( $main_color ) . ';
                }
                .woocommerce-product-details__short-description li::before {
                    border-color: transparent transparent transparent ' . esc_attr( $main_color ) . ';
                }
                .wc-tabs li a::before {
                    border-bottom: 3px solid ' . esc_attr( $main_color ) . ';
                }
                .famibt-messages-wrap a.button.wc-forward:hover {
                    background: ' . esc_attr( $main_color ) . ';
                }
                .panel-categories .panel-categories-inner > a::before {
                    border-bottom: 2px solid ' . esc_attr( $main_color ) . ';
                }
                .products-size.active svg, .products-size:hover svg {
                    stroke: ' . esc_attr( $main_color ) . ';
                    fill: ' . esc_attr( $main_color ) . ';
                }
                .price_slider_amount .button:hover, .price_slider_amount .button:focus {
                    background-color: ' . esc_attr( $main_color ) . ';
                    border: 2px solid ' . esc_attr( $main_color ) . ';
                }
                .WOOF_Widget .woof_container li .icheckbox_flat-purple.hover,
                .WOOF_Widget .woof_container li .iradio_flat-purple.hover,
                .icheckbox_flat-purple.checked,
                .iradio_flat-purple.checked {
                    background: ' . esc_attr( $main_color ) . ' 0 0 !important;
                    border: 1px solid ' . esc_attr( $main_color ) . ' !important;
                }
                .cize-title.style-03 .block-title::before {
                    border: 1px solid ' . esc_attr( $main_color ) . ';
                }
                .cize-demo.style-02 .demo-title::before {
                    border-bottom: 1px solid ' . esc_attr( $main_color ) . ';
                }
               
                .toolbar-products .category-filter li a::before {
                    border-bottom: 1px solid ' . esc_attr( $main_color ) . ';
                }
                div.prdctfltr_wc.prdctfltr_round .prdctfltr_filter label.prdctfltr_active > span::before,
                div.prdctfltr_wc.prdctfltr_round .prdctfltr_filter label:hover > span::before {
                    background: ' . esc_attr( $main_color ) . ';
                    border: 1px double ' . esc_attr( $main_color ) . ';
                    color: ' . esc_attr( $main_color ) . ';
                }
                .prdctfltr_filter .prdctfltr_regular_title::before {
                    border-top: 1px solid ' . esc_attr( $main_color ) . ';
                }
                .prdctfltr_woocommerce_filter_submit:hover, .prdctfltr_wc .prdctfltr_buttons .prdctfltr_reset span:hover, .prdctfltr_sale:hover,
                .prdctfltr_instock:hover,
                .prdctfltr-pagination-load-more:not(.prdctfltr-ignite) .button:hover,
                div.pf_rngstyle_flat .irs-from, div.pf_rngstyle_flat .irs-to, div.pf_rngstyle_flat .irs-single,
                div.pf_rngstyle_flat .irs-bar,
                .enable-shop-page-mobile span.prdctfltr_title_selected {
                    background: ' . esc_attr( $main_color ) . ';
                }
                .prdctfltr_sc.hide-cat-thumbs .product-category h2.woocommerce-loop-category__title::before {
                    border-bottom: 1px solid ' . esc_attr( $main_color ) . ';
                }
                div.pf_rngstyle_flat .irs-from::after, div.pf_rngstyle_flat .irs-to::after, div.pf_rngstyle_flat .irs-single::after {
                    border-top-color: ' . esc_attr( $main_color ) . ';
                }
                div.pf_rngstyle_flat .irs-bar::after,
                div.pf_rngstyle_flat .irs-bar::before {
                    border: 2px solid ' . esc_attr( $main_color ) . ';
                }
                
                .yith-wcqv-button .blockOverlay,
                .compare .blockOverlay {
                    background: ' . esc_attr( $main_color ) . ' !important;
                }
                #popup-newsletter button.close:hover,
                .cize-heading.style-02 .icon,
                 body .vc_toggle_default.vc_toggle_active .vc_toggle_title > h4,
                .single-product-mobile .product-grid .product-info .price,
                div.cize-content-single-product-mobile .summary .yith-wcwl-add-to-wishlist,
                body.wpb-js-composer .vc_tta-style-classic .vc_tta-panel.vc_active .vc_tta-panel-title > a {
                    color: ' . esc_attr( $main_color ) . ' !important;
                }
                .cize-mapper .cize-pin .cize-popup-footer a:hover {
                    background: ' . esc_attr( $main_color ) . ' !important;
                    border-color: ' . esc_attr( $main_color ) . ' !important;
                }
                @media (min-width: 992px) {
                    .ziss-popup-wrap .ziss-popup-inner .ziss-popup-body.ziss-right-no-content ~ .ziss-popup-nav:hover,
                    .ziss-popup-wrap .ziss-popup-inner .ziss-popup-body:not(.ziss-right-no-content) ~ .ziss-popup-nav:hover {
                        color: ' . esc_attr( $main_color ) . ';
                    }
                }
		';
		
		if ( $body_text_color && $body_text_color != '' ) {
			$css .= 'body {color: ' . esc_attr( $body_text_color ) . '}';
		}
		
		return $css;
	}
}

if ( ! function_exists( 'cize_vc_custom_css_footer' ) ) {
	function cize_vc_custom_css_footer() {
		
		$cize_footer_options = cize_get_option( 'cize_footer_options', '' );
		$page_id              = cize_get_single_page_id();
		
		$data_option_meta = get_post_meta( $page_id, '_custom_metabox_theme_options', true );
		if ( $page_id > 0 ) {
			$enable_custom_footer = false;
			if ( isset( $data_option_meta['enable_custom_footer'] ) ) {
				$enable_custom_footer = $data_option_meta['enable_custom_footer'];
			}
			if ( $enable_custom_footer ) {
				$cize_footer_options = $data_option_meta['cize_metabox_footer_options'];
			}
		}
		
		$shortcodes_custom_css = get_post_meta( $cize_footer_options, '_wpb_post_custom_css', true );
		$shortcodes_custom_css .= get_post_meta( $cize_footer_options, '_wpb_shortcodes_custom_css', true );
		$shortcodes_custom_css .= get_post_meta( $cize_footer_options, '_cize_shortcode_custom_css', true );
		$shortcodes_custom_css .= get_post_meta( $cize_footer_options, '_responsive_js_composer_shortcode_custom_css', true );
		
		return $shortcodes_custom_css;
	}
}
