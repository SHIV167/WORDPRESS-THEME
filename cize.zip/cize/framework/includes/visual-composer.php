<?php
if ( ! class_exists( 'Cize_Visual_Composer' ) ) {
	class Cize_Visual_Composer {
		public function __construct() {
			$this->define_constants();
			add_filter( 'vc_google_fonts_get_fonts_filter', array( $this, 'vc_fonts' ) );
			$this->params();
			$this->autocomplete();
			/* Custom font Icon*/
			add_filter( 'vc_iconpicker-type-cizecustomfonts', array( &$this, 'iconpicker_type_cize_customfonts' ) );
			$this->map_shortcode();
		}

		/**
		 * Define  Constants.
		 */
		private function define_constants() {
			$this->define( 'CIZE_SHORTCODE_PREVIEW', get_theme_file_uri( '/framework/assets/images/shortcode-previews/' ) );
			$this->define( 'CIZE_SHORTCODES_ICONS_URI', get_theme_file_uri( '/framework/assets/images/vc-shortcodes-icons/' ) );
			$this->define( 'CIZE_PRODUCT_STYLE_PREVIEW', get_theme_file_uri( '/woocommerce/product-styles/' ) );
			$this->define( 'CIZE_PRODUCT_DEAL_PREVIEW', get_theme_file_uri( '/woocommerce/product-deal/' ) );

		}

		/**
		 * Define constant if not already set.
		 *
		 * @param  string      $name
		 * @param  string|bool $value
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		function params() {
			if ( function_exists( 'cize_toolkit_vc_param' ) ) {
				cize_toolkit_vc_param( 'taxonomy', array( $this, 'taxonomy_field' ) );
				cize_toolkit_vc_param( 'uniqid', array( $this, 'uniqid_field' ) );
				cize_toolkit_vc_param( 'select_preview', array( $this, 'select_preview_field' ) );
				cize_toolkit_vc_param( 'number', array( $this, 'number_field' ) );
			}
		}

		/**
		 * load param autocomplete render
		 * */
		public function autocomplete() {
			add_filter( 'vc_autocomplete_cize_products_ids_callback', array(
				$this,
				'productIdAutocompleteSuggester'
			), 10, 1 );
			add_filter( 'vc_autocomplete_cize_products_ids_render', array(
				$this,
				'productIdAutocompleteRender'
			), 10, 1 );
			add_filter( 'vc_autocomplete_cize_dealproduct_ids_callback', array(
				$this,
				'productIdAutocompleteSuggester'
			), 10, 1 );
			add_filter( 'vc_autocomplete_cize_dealproduct_ids_render', array(
				$this,
				'productIdAutocompleteRender'
			), 10, 1 );
			add_filter( 'vc_autocomplete_cize_pinmap_ids_callback', array(
				$this,
				'pinmapIdAutocompleteSuggester'
			), 10, 1 );
			add_filter( 'vc_autocomplete_cize_pinmap_ids_render', array(
				$this,
				'pinmapIdAutocompleteRender'
			), 10, 1 );

		}

		/*
         * taxonomy_field
         * */
		public function taxonomy_field( $settings, $value ) {
			$dependency = '';
			$value_arr  = $value;
			if ( ! is_array( $value_arr ) ) {
				$value_arr = array_map( 'trim', explode( ',', $value_arr ) );
			}
			$output = '';
			if ( isset( $settings['hide_empty'] ) && $settings['hide_empty'] ) {
				$settings['hide_empty'] = 1;
			} else {
				$settings['hide_empty'] = 0;
			}
			if ( ! empty( $settings['taxonomy'] ) ) {
				$terms_fields = array();
				if ( isset( $settings['placeholder'] ) && $settings['placeholder'] ) {
					$terms_fields[] = "<option value=''>" . $settings['placeholder'] . "</option>";
				}
				$terms = get_terms( $settings['taxonomy'], array(
					'parent'     => $settings['parent'],
					'hide_empty' => $settings['hide_empty']
				) );
				if ( $terms && ! is_wp_error( $terms ) ) {
					foreach ( $terms as $term ) {
						$selected       = ( in_array( $term->slug, $value_arr ) ) ? ' selected="selected"' : '';
						$terms_fields[] = "<option value='{$term->slug}' {$selected}>{$term->name}</option>";
					}
				}
				$size     = ( ! empty( $settings['size'] ) ) ? 'size="' . $settings['size'] . '"' : '';
				$multiple = ( ! empty( $settings['multiple'] ) ) ? 'multiple="multiple"' : '';
				$uniqeID  = uniqid();
				$output   = '<select style="width:100%;" id="vc_taxonomy-' . $uniqeID . '" ' . $multiple . ' ' . $size . ' name="' . $settings['param_name'] . '" class="cize_vc_taxonomy wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				            . implode( $terms_fields )
				            . '</select>';
			}

			return $output;
		}

		public function uniqid_field( $settings, $value ) {
			if ( ! $value ) {
				$value = uniqid( hash( 'crc32', $settings['param_name'] ) . '-' );
			}
			$output = '<input type="text" class="wpb_vc_param_value textfield" name="' . $settings['param_name'] . '" value="' . esc_attr( $value ) . '" />';

			return $output;
		}

		public function number_field( $settings, $value ) {
			$dependency = '';
			$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
			$type       = isset( $settings['type '] ) ? $settings['type'] : '';
			$min        = isset( $settings['min'] ) ? $settings['min'] : '';
			$max        = isset( $settings['max'] ) ? $settings['max'] : '';
			$suffix     = isset( $settings['suffix'] ) ? $settings['suffix'] : '';
			$class      = isset( $settings['class'] ) ? $settings['class'] : '';
			if ( ! $value && isset( $settings['std'] ) ) {
				$value = $settings['std'];
			}
			$output = '<input type="number" min="' . esc_attr( $min ) . '" max="' . esc_attr( $max ) . '" class="wpb_vc_param_value textfield ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . esc_attr( $value ) . '" ' . $dependency . ' style="max-width:100px; margin-right: 10px;" />' . $suffix;

			return $output;
		}

		public function select_preview_field( $settings, $value ) {
			ob_start();
			// Get menus list
			$options = $settings['value'];
			$default = $settings['default'];
			if ( is_array( $options ) && count( $options ) > 0 ) {
				$uniqeID = uniqid();
				$i       = 0;
				?>
                <div class="container-select_preview">
                    <select id="cize_select_preview-<?php echo esc_attr( $uniqeID ); ?>"
                            name="<?php echo esc_attr( $settings['param_name'] ); ?>"
                            class="cize_select_preview vc_select_image wpb_vc_param_value wpb-input wpb-select <?php echo esc_attr( $settings['param_name'] ); ?> <?php echo esc_attr( $settings['type'] ); ?>_field">
						<?php foreach ( $options as $k => $option ): ?>
							<?php
							if ( $i == 0 ) {
								$first_value = $k;
							}
							$i ++;
							?>
							<?php $selected = ( $k == $value ) ? ' selected="selected"' : ''; ?>
                            <option data-img="<?php echo esc_url( $option['img'] ); ?>"
                                    value='<?php echo esc_attr( $k ) ?>' <?php echo esc_attr( $selected ) ?>><?php echo esc_attr( $option['alt'] ) ?></option>
						<?php endforeach; ?>
                    </select>
                    <div class="image-preview">
						<?php if ( isset( $options[ $value ] ) && $options[ $value ] && ( isset( $options[ $value ]['img'] ) ) ): ?>
                            <img style="margin-top: 10px; max-width: 100%;height: auto;"
                                 src="<?php echo esc_url( $options[ $value ]['img'] ); ?>">
						<?php else: ?>
                            <img style="margin-top: 10px; max-width: 100%;height: auto;"
                                 src="<?php echo esc_url( $options[ $default ]['img'] ); ?>">
						<?php endif; ?>
                    </div>
                </div>
				<?php
			}

			return ob_get_clean();
		}

		/**
		 * Suggester for autocomplete by id/name/title/sku
		 *
		 * @since  1.0
		 *
		 * @param $query
		 *
		 * @author Reapple
		 * @return array - id's from products with title/sku.
		 */
		public function productIdAutocompleteSuggester( $query ) {
			global $wpdb;
			$product_id      = (int) $query;
			$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.ID AS id, a.post_title AS title, b.meta_value AS sku
    					FROM {$wpdb->posts} AS a
    					LEFT JOIN ( SELECT meta_value, post_id  FROM {$wpdb->postmeta} WHERE `meta_key` = '_sku' ) AS b ON b.post_id = a.ID
    					WHERE a.post_type = 'product' AND ( a.ID = '%d' OR b.meta_value LIKE '%%%s%%' OR a.post_title LIKE '%%%s%%' )", $product_id > 0 ? $product_id : - 1, stripslashes( $query ), stripslashes( $query )
			), ARRAY_A
			);
			$results         = array();
			if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
				foreach ( $post_meta_infos as $value ) {
					$data          = array();
					$data['value'] = $value['id'];
					$data['label'] = esc_html__( 'Id', 'cize' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'cize' ) . ': ' . $value['title'] : '' ) . ( ( strlen( $value['sku'] ) > 0 ) ? ' - ' . esc_html__( 'Sku', 'cize' ) . ': ' . $value['sku'] : '' );
					$results[]     = $data;
				}
			}

			return $results;
		}

		/**
		 * Find product by id
		 *
		 * @since  1.0
		 *
		 * @param $query
		 *
		 * @author Reapple
		 *
		 * @return bool|array
		 */
		public function productIdAutocompleteRender( $query ) {
			$query = trim( $query['value'] ); // get value from requested
			if ( ! empty( $query ) ) {
				// get product
				$product_object = wc_get_product( (int) $query );
				if ( is_object( $product_object ) ) {
					$product_sku         = $product_object->get_sku();
					$product_title       = $product_object->get_title();
					$product_id          = $product_object->get_id();
					$product_sku_display = '';
					if ( ! empty( $product_sku ) ) {
						$product_sku_display = ' - ' . esc_html__( 'Sku', 'cize' ) . ': ' . $product_sku;
					}
					$product_title_display = '';
					if ( ! empty( $product_title ) ) {
						$product_title_display = ' - ' . esc_html__( 'Title', 'cize' ) . ': ' . $product_title;
					}
					$product_id_display = esc_html__( 'Id', 'cize' ) . ': ' . $product_id;
					$data               = array();
					$data['value']      = $product_id;
					$data['label']      = $product_id_display . $product_title_display . $product_sku_display;

					return ! empty( $data ) ? $data : false;
				}

				return false;
			}

			return false;
		}

		/**
		 * Suggester for autocomplete by id/name/title
		 *
		 * @since  1.0
		 *
		 * @param $query
		 *
		 * @author Reapple
		 * @return array - id's from post_types with title/.
		 */
		public function pinmapIdAutocompleteSuggester( $query ) {
			global $wpdb;
			$post_type_id    = (int) $query;
			$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.ID AS id, a.post_title AS title 
    					FROM {$wpdb->posts} AS a 
    					WHERE a.post_type = 'cize_mapper' AND ( a.ID = '%d' OR a.post_title LIKE '%%%s%%' )", $post_type_id > 0 ? $post_type_id : - 1, stripslashes( $query ), stripslashes( $query )
			), ARRAY_A
			);
			$results         = array();
			if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
				foreach ( $post_meta_infos as $value ) {
					$data          = array();
					$data['value'] = $value['id'];
					$data['label'] = esc_html__( 'Id', 'cize' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'cize' ) . ': ' . $value['title'] : '' );
					$results[]     = $data;
				}
			}

			return $results;
		}

		/**
		 * Find product by id
		 *
		 * @since  1.0
		 *
		 * @param $query
		 *
		 * @author Reapple
		 *
		 * @return bool|array
		 */
		public function pinmapIdAutocompleteRender( $query ) {
			$query = trim( $query['value'] ); // get value from requested
			if ( ! empty( $query ) ) {
				// get post_type
				$post_type_object = wc_get_post_type( (int) $query );
				if ( is_object( $post_type_object ) ) {
					$post_type_title = $post_type_object->get_title();
					$post_type_id    = $post_type_object->get_id();

					$post_type_title_display = '';
					if ( ! empty( $post_type_title ) ) {
						$post_type_title_display = ' - ' . esc_html__( 'Title', 'cize' ) . ': ' . $post_type_title;
					}
					$post_type_id_display = esc_html__( 'Id', 'cize' ) . ': ' . $post_type_id;
					$data                 = array();
					$data['value']        = $post_type_id;
					$data['label']        = $post_type_id_display . $post_type_title_display;

					return ! empty( $data ) ? $data : false;
				}

				return false;
			}

			return false;
		}

		public function vc_fonts( $fonts_list ) {
			/* Gotham */
			$Gotham              = new stdClass();
			$Gotham->font_family = "Gotham";
			$Gotham->font_styles = "100,300,400,600,700";
			$Gotham->font_types  = "300 Light:300:light,400 Normal:400:normal";

			$fonts = array( $Gotham );

			return array_merge( $fonts_list, $fonts );
		}

		/* Custom Font icon*/
		function iconpicker_type_cize_customfonts( $icons ) {
			$icons['Flaticon'] = array(
                array('flaticon-magnifying-glass'=>'Flaticon magnifying glass'),
                array('flaticon-profile'=>'Flaticon profile'),
                array('flaticon-bag'=>'Flaticon bag'),
                array('flaticon-right-arrow'=>'Flaticon right arrow'),
                array('flaticon-left-arrow'=>'Flaticon left arrow'),
                array('flaticon-right-arrow-1'=>'Flaticon right arrow 1'),
                array('flaticon-left-arrow-1'=>'Flaticon left arrow 1'),
                array('flaticon-mail'=>'Flaticon mail'),
                array('flaticon-flame'=>'Flaticon flame'),
                array('flaticon-clock'=>'Flaticon clock'),
                array('flaticon-comment'=>'Flaticon comment'),
                array('flaticon-chat'=>'Flaticon chat'),
                array('flaticon-heart'=>'Flaticon heart'),
                array('flaticon-valentines-heart'=>'Flaticon valentines heart'),
                array('flaticon-filter'=>'Flaticon filter'),
                array('flaticon-loading'=>'Flaticon loading'),
                array('flaticon-checked'=>'Flaticon checked'),
                array('flaticon-tick'=>'Flaticon tick'),
                array('flaticon-close'=>'Flaticon close'),
                array('flaticon-circular-check-button'=>'Flaticon circular check button'),
                array('flaticon-check'=>'Flaticon check'),
                array('flaticon-play-button'=>'Flaticon play button'),
                array('flaticon-360-degrees'=>'Flaticon 360 degrees'),
                array('flaticon-login'=>'Flaticon login'),
                array('flaticon-menu'=>'Flaticon menu'),
                array('flaticon-menu-1'=>'Flaticon menu 1'),
                array('flaticon-placeholder'=>'Flaticon placeholder'),
                array('flaticon-metre'=>'Flaticon metre'),
                array('flaticon-share'=>'Flaticon share'),
                array('flaticon-shuffle'=>'Flaticon shuffle'),
			);

			return $icons;
		}

		public function animation_on_scroll() {
		    return array(
			    esc_html__( 'None', 'cize' )      => '',
			    esc_html__( 'Smooth Up', 'cize' ) => 'cize-wow fadeInUp',
			    esc_html__( 'Smooth Down', 'cize' ) => 'cize-wow fadeInDown',
			    esc_html__( 'Smooth Left', 'cize' ) => 'cize-wow fadeInLeft',
			    esc_html__( 'Smooth Right', 'cize' ) => 'cize-wow fadeInRight',
		    );
        }

		public function map_shortcode() {
			/* Map New Banner */
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Banner', 'cize' ),
					'base'        => 'cize_banner', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a Banner list.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'banner.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-02.jpg',
								),
								'style-03' => array(
									'alt' => 'Style 03', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-03.jpg',
								),
								'style-04' => array(
									'alt' => 'Style 04', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-04.jpg',
								),
								'style-05' => array(
									'alt' => 'Style 05', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-05.jpg',
								),
								'style-06' => array(
									'alt' => 'Style 06', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-06.jpg',
								),
								'style-07' => array(
									'alt' => 'Style 07', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-07.jpg',
								),
                                'style-08' => array(
                                    'alt' => 'Style 08', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-08.jpg',
                                ),
                                'style-09' => array(
                                    'alt' => 'Style 09', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-09.jpg',
                                ),
                                'style-10' => array(
                                    'alt' => 'Style 10', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'banner/style-10.jpg',
                                ),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The title of shortcode', 'cize' ),
							'dependency'  => array(
								'element' => 'style',
								'value'   => array(
									'style-04',
									'style-05',
									'style-06',
								),
							),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Big Title', 'cize' ),
							'param_name'  => 'bigtitle',
							'description' => esc_html__( 'The big title of shortcode', 'cize' ),
                            "admin_label" => true,
						),
						array(
							'type'       => 'textfield',
							'heading'    => esc_html__( 'Description', 'cize' ),
							'param_name' => 'desc',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array(
                                    'style-01',
                                    'style-02',
                                    'style-03',
                                    'style-04',
                                    'style-07',
                                    'style-08',
                                    'style-09',
                                    'style-10',
                                ),
                            ),
						),
						array(
							'type'        => 'vc_link',
							'heading'     => esc_html__( 'Banner Link', 'cize' ),
							'param_name'  => 'link',
							'description' => esc_html__( 'Add banner link.', 'cize' ),
						),
                        array(
                            'param_name' => 'button_color',
                            'heading'    => esc_html__( 'Button Color', 'cize' ),
                            'type'       => 'dropdown',
                            'value'      => array(
                                esc_html__( 'Dark', 'cize' )  => '',
                                esc_html__( 'Light', 'cize' ) => 'light',
                            ),
                            'std'        => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-04'),
                            ),
                        ),
                        array(
                            'param_name' => 'position',
                            'heading'    => esc_html__( 'Content', 'cize' ),
                            'type'       => 'dropdown',
                            'value'      => array(
                                esc_html__( 'Top', 'cize' )  => '',
                                esc_html__( 'Bottom', 'cize' ) => 'bottom',
                            ),
                            'std'        => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-05','style-06'),
                            ),
                        ),
						array(
							"type"        => "attach_image",
							"heading"     => esc_html__( "Image", "cize" ),
							"param_name"  => "image",
							"admin_label" => false,
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'banner_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			/* Map New blog */
			$categories_array = array(
				esc_html__( 'All', 'cize' ) => '',
			);
			$args             = array();
			$categories       = get_categories( $args );
			foreach ( $categories as $category ) {
				$categories_array[ $category->name ] = $category->slug;
			}

			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Blog', 'cize' ),
					'base'        => 'cize_blog', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a blog list.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'blog.png',
					'params'      => array(
						array(
							"type"       => "textfield",
							"heading"    => esc_html__( "Section title", "cize" ),
							"param_name" => "title",
						),
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'blog/style-01.jpg',
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Number Post', 'cize' ),
							'param_name'  => 'per_page',
							'std'         => 10,
							'admin_label' => true,
							'description' => esc_html__( 'Number post in a slide', 'cize' ),
						),
						array(
							'param_name'  => 'category_slug',
							'type'        => 'dropdown',
							'value'       => $categories_array,
							'heading'     => esc_html__( 'Category filter:', 'cize' ),
							"admin_label" => true,
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order by", 'cize' ),
							"param_name"  => "orderby",
							"value"       => array(
								esc_html__( 'None', 'cize' )     => 'none',
								esc_html__( 'ID', 'cize' )       => 'ID',
								esc_html__( 'Author', 'cize' )   => 'author',
								esc_html__( 'Name', 'cize' )     => 'name',
								esc_html__( 'Date', 'cize' )     => 'date',
								esc_html__( 'Modified', 'cize' ) => 'modified',
								esc_html__( 'Rand', 'cize' )     => 'rand',
							),
							'std'         => 'date',
							"description" => esc_html__( "Select how to sort retrieved posts.", 'cize' ),
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order", 'cize' ),
							"param_name"  => "order",
							"value"       => array(
								esc_html__( 'ASC', 'cize' )  => 'ASC',
								esc_html__( 'DESC', 'cize' ) => 'DESC',
							),
							'std'         => 'DESC',
							"description" => esc_html__( "Designates the ascending or descending order.", 'cize' ),
						),
						/* Owl */
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'AutoPlay', 'cize' ),
							'param_name'  => 'autoplay',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Navigation', 'cize' ),
							'param_name'  => 'navigation',
							'description' => esc_html__( "Show buton 'next' and 'prev' buttons.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Enable Dots', 'cize' ),
							'param_name'  => 'dots',
							'description' => esc_html__( "Show buton dots.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Loop', 'cize' ),
							'param_name'  => 'loop',
							'description' => esc_html__( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Slide Speed", 'cize' ),
							"param_name"  => "slidespeed",
							"value"       => "200",
							"description" => esc_html__( 'Slide speed in milliseconds', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Margin", 'cize' ),
							"param_name"  => "margin",
							"value"       => "30",
							"description" => esc_html__( 'Distance( or space) between 2 item', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Auto Responsive Margin', 'cize' ),
							'param_name' => 'autoresponsive',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							'value'      => array(
								esc_html__( 'No', 'cize' )  => '',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'        => '',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1500px )", 'cize' ),
							"param_name"  => "ls_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1200px < 1500px )", 'cize' ),
							"param_name"  => "lg_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 992px < 1200px )", 'cize' ),
							"param_name"  => "md_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on tablet (Screen resolution of device >=768px and < 992px )", 'cize' ),
							"param_name"  => "sm_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile landscape(Screen resolution of device >=480px and < 768px)", 'cize' ),
							"param_name"  => "xs_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile (Screen resolution of device < 480px)", 'cize' ),
							"param_name"  => "ts_items",
							"value"       => "1",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'blog_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			/* Map New Category */
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Categories', 'cize' ),
					'base'        => 'cize_categories', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display Category.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'cat.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select Style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'categories/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02',
									'img' => CIZE_SHORTCODE_PREVIEW . 'categories/style-02.jpg',
								),
								'style-03' => array(
									'alt' => 'Style 03',
									'img' => CIZE_SHORTCODE_PREVIEW . 'categories/style-03.jpg',
								),
                                'style-04' => array(
                                    'alt' => 'Style 04',
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'categories/style-04.jpg',
                                ),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'description' => esc_html__( 'The title of shortcode', 'cize' ),
                            'admin_label' => true,
                            'std'         => '',
                        ),
						array(
							"type"        => "taxonomy",
							"taxonomy"    => "product_cat",
							"class"       => "",
							"heading"     => esc_html__( "Product Category", 'cize' ),
							"param_name"  => "taxonomy",
							"value"       => '',
							'parent'      => '',
							'multiple'    => true,
							'hide_empty'  => false,
							"description" => esc_html__( "Note: If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'cize' ),
							'std'         => '',
						),
                        array(
                            'type'        => 'vc_link',
                            'heading'     => esc_html__( 'Link', 'cize' ),
                            'param_name'  => 'link',
                            'description' => esc_html__( 'Add link.', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-01','style-02'),
                            ),
                        ),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
                        /* OWL Settings */
                        array(
                            'type'        => 'dropdown',
                            'value'       => array(
                                esc_html__( 'Yes', 'cize' ) => 'true',
                                esc_html__( 'No', 'cize' )  => 'false',
                            ),
                            'std'         => 'false',
                            'heading'     => esc_html__( 'AutoPlay', 'cize' ),
                            'param_name'  => 'autoplay',
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'value'       => array(
                                esc_html__( 'No', 'cize' )  => 'false',
                                esc_html__( 'Yes', 'cize' ) => 'true',
                            ),
                            'std'         => false,
                            'heading'     => esc_html__( 'Navigation', 'cize' ),
                            'param_name'  => 'navigation',
                            'description' => esc_html__( "Show buton 'next' and 'prev' buttons.", 'cize' ),
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                            'admin_label' => false,
                        ),
                        array(
                            'type'        => 'dropdown',
                            'value'       => array(
                                esc_html__( 'Center', 'cize' ) => 'nav-center',
                                esc_html__( 'Left', 'cize' )   => 'nav-left',
                            ),
                            'std'         => 'nav-center',
                            'heading'     => esc_html__( 'Nav Position', 'cize' ),
                            'param_name'  => 'nav_position',
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            "dependency"  => array(
                                "element" => "navigation",
                                "value"   => array( 'true' ),
                            ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'value'       => array(
                                esc_html__( 'No', 'cize' )  => 'false',
                                esc_html__( 'Yes', 'cize' ) => 'true',
                            ),
                            'std'         => false,
                            'heading'     => esc_html__( 'Enable Dots', 'cize' ),
                            'param_name'  => 'dots',
                            'description' => esc_html__( "Show buton dots", 'cize' ),
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                            'admin_label' => false,
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "Slide Speed", 'cize' ),
                            "param_name"  => "slidespeed",
                            "value"       => "200",
                            "suffix"      => esc_html__( "milliseconds", 'cize' ),
                            "description" => esc_html__( 'Slide speed in milliseconds', 'cize' ),
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "Margin", 'cize' ),
                            "param_name"  => "margin",
                            "value"       => "0",
                            "description" => esc_html__( 'Distance( or space) between 2 item', 'cize' ),
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Auto Responsive Margin', 'cize' ),
                            'param_name' => 'autoresponsive',
                            'group'      => esc_html__( 'Carousel settings', 'cize' ),
                            'value'      => array(
                                esc_html__( 'No', 'cize' )  => '',
                                esc_html__( 'Yes', 'cize' ) => 'true',
                            ),
                            'std'        => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1500px )", 'cize' ),
                            "param_name"  => "ls_items",
                            "value"       => "5",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1200px and < 1500px )", 'cize' ),
                            "param_name"  => "lg_items",
                            "value"       => "4",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 992px < 1200px )", 'cize' ),
                            "param_name"  => "md_items",
                            "value"       => "3",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on tablet (Screen resolution of device >=768px and < 992px )", 'cize' ),
                            "param_name"  => "sm_items",
                            "value"       => "3",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on mobile landscape(Screen resolution of device >=480px and < 768px)", 'cize' ),
                            "param_name"  => "xs_items",
                            "value"       => "2",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "The items on mobile (Screen resolution of device < 480px)", 'cize' ),
                            "param_name"  => "ts_items",
                            "value"       => "2",
                            'group'       => esc_html__( 'Carousel settings', 'cize' ),
                            'admin_label' => false,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-03' ),
                            ),
                        ),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'categories_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
            vc_map(
                array(
                    'base'        => 'cize_contact',
                    'name'        => esc_html__( 'Cize: Contact', 'cize' ),
                    'icon'        => CIZE_SHORTCODES_ICONS_URI . 'cat.png',
                    'category'    => esc_html__( 'Cize Elements', 'cize' ),
                    'description' => esc_html__( 'Display Custom Contact', 'cize' ),
                    'params'      => array(
                        array(
                            'type'        => 'select_preview',
                            'heading'     => esc_html__( 'Select style', 'cize' ),
                            'value'       => array(
                                'style-01' => array(
                                    'alt' => 'Style 01',
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'contact/style-01.jpg',
                                ),
                                'style-02' => array(
                                    'alt' => 'Style 02',
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'contact/style-02.jpg',
                                ),
                            ),
                            'default'     => 'style-01',
                            'admin_label' => true,
                            'param_name'  => 'style',
                        ),
                        array(
                            'type'       => 'param_group',
                            'heading'    => esc_html__( 'Contact Items', 'cize' ),
                            'param_name' => 'contact_item',
                            'params'     => array(
                                array(
                                    'type'        => 'textfield',
                                    'heading'     => esc_html__( 'Title', 'cize' ),
                                    'param_name'  => 'title_item',
                                    'admin_label' => true,
                                ),
                                array(
                                    'type'       => 'vc_link',
                                    'heading'    => esc_html__( 'Link', 'cize' ),
                                    'param_name' => 'link_item',
                                ),
                            ),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'animate_on_scroll',
                            'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
                            'value'      => $this->animation_on_scroll(),
                            'std'        => ''
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "Extra class name", "cize" ),
                            "param_name"  => "el_class",
                            "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
                        ),
                        array(
                            'type'       => 'css_editor',
                            'heading'    => esc_html__( 'Css', 'cize' ),
                            'param_name' => 'css',
                            'group'      => esc_html__( 'Design Options', 'cize' ),
                        ),
                        array(
                            'param_name'       => 'contact_custom_id',
                            'heading'          => esc_html__( 'Hidden ID', 'cize' ),
                            'type'             => 'uniqid',
                            'edit_field_class' => 'hidden',
                        ),
                    ),
                )
            );
			/*Map New Custom menu*/
			$all_menu = array();
			$menus    = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
			if ( $menus && count( $menus ) > 0 ) {
				foreach ( $menus as $m ) {
					$all_menu[ $m->name ] = $m->slug;
				}
			}
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Custom Menu', 'cize' ),
					'base'        => 'cize_custommenu', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a custom menu.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'custom-menu.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select Style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'custommenu/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02',
									'img' => CIZE_SHORTCODE_PREVIEW . 'custommenu/style-02.jpg',
								),
								'style-03' => array(
									'alt' => 'Style 03',
									'img' => CIZE_SHORTCODE_PREVIEW . 'custommenu/style-03.jpg',
								),
								'style-04' => array(
									'alt' => 'Style 04',
									'img' => CIZE_SHORTCODE_PREVIEW . 'custommenu/style-04.jpg',
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The title of shortcode', 'cize' ),
							'admin_label' => true,
							'std'         => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-01','style-02' ),
                            ),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Menu', 'cize' ),
							'param_name'  => 'menu',
							'value'       => $all_menu,
							'description' => esc_html__( 'Select menu to display.', 'cize' ),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'custommenu_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Demo', 'cize' ),
					'base'        => 'cize_demo', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a demo list.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'banner.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'demo/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'demo/style-02.jpg',
								),
                                'style-03' => array(
                                    'alt' => 'Style 03', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'demo/style-03.jpg',
                                ),
                                'style-04' => array(
                                    'alt' => 'Style 04', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'demo/style-04.jpg',
                                ),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							"type"        => "attach_image",
							"heading"     => esc_html__( "Image", "cize" ),
							"param_name"  => "image",
							"admin_label" => false,
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'admin_label' => true,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-02','style-04' ),
                            ),
						),
						array(
							'type'        => 'textarea_html',
							'heading'     => esc_html__( 'Description', 'cize' ),
							'param_name'  => 'content',
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-02','style-03' ),
							),
						),
						array(
							'type'        => 'vc_link',
							'heading'     => esc_html__( 'Demo Link', 'cize' ),
							'param_name'  => 'link',
							'description' => esc_html__( 'Add demo link.', 'cize' ),
							'admin_label' => true,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-01','style-02','style-04' ),
                            ),
						),
                        array(
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Content Position', 'cize' ),
                            'value'      => array(
                                esc_html__( 'Content Right', 'cize' )  => '',
                                esc_html__( 'Content Left', 'cize' )   => 'content-left',
                            ),
                            'param_name' => 'content_position',
                            'std'        => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-02' ),
                            ),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Comming soon mode', 'cize' ),
                            'value'      => array(
                                esc_html__( 'Off', 'cize' )  => '',
                                esc_html__( 'On', 'cize' ) => 'comming-mode',
                            ),
                            'param_name' => 'comming',
                            'std'        => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( 'style-01','style-04' ),
                            ),
                        ),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'demo_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			/*Section IconBox*/
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Icon Box', 'cize' ),
					'base'        => 'cize_iconbox', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display Iconbox.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'iconbox.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Layout', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'iconbox/style-01.jpg'
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Choose icon or image', 'cize' ),
							'value'      => array(
								esc_html__( 'Icon', 'cize' )  => '',
								esc_html__( 'Image', 'cize' ) => 'imagetype',
							),
							'param_name' => 'iconimage',
							'std'        => '',
						),
						array(
							"type"       => "attach_image",
							"heading"    => esc_html__( "Image custom", "cize" ),
							"param_name" => "image",
							'dependency' => array(
								'element' => 'iconimage',
								'value'   => 'imagetype',
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Icon library', 'cize' ),
							'value'       => array(
								esc_html__( 'Font Awesome', 'cize' )  => 'fontawesome',
								esc_html__( 'Font Flaticon', 'cize' ) => 'fontflaticon',
							),
							'admin_label' => true,
							'param_name'  => 'i_type',
							'description' => esc_html__( 'Select icon library.', 'cize' ),
							'std'         => 'fontawesome',
							'dependency'  => array(
								'element' => 'iconimage',
								'value'   => array( '' ),
							),
						),
						array(
							'param_name'  => 'icon_cizecustomfonts',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
							'type'        => 'iconpicker',
							'settings'    => array(
								'emptyIcon' => true,
								'type'      => 'cizecustomfonts',
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontflaticon',
							),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'param_name'  => 'icon_fontawesome',
							'value'       => 'fa fa-adjust',
							'settings'    => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontawesome',
							),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
						),
						array(
							'type'        => 'textarea',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The Title of IconBox.', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'        => 'textarea',
							'heading'     => esc_html__( 'Description', 'cize' ),
							'param_name'  => 'des',
							'description' => esc_html__( 'The Description of IconBox.', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", 'cize' ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'iconbox_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),

					)
				)
			);
			/* Map New Section tabs */
			vc_map(
				array(
					'name'                      => esc_html__( 'Section', 'cize' ),
					'base'                      => 'vc_tta_section',
					'icon'                      => 'icon-wpb-ui-tta-section',
					'allowed_container_element' => 'vc_row',
					'is_container'              => true,
					'show_settings_on_create'   => false,
					'as_child'                  => array(
						'only' => 'vc_tta_tour,vc_tta_tabs,vc_tta_accordion',
					),
					'category'                  => esc_html__( 'Content', 'cize' ),
					'description'               => esc_html__( 'Section for Tabs, Tours, Accordions.', 'cize' ),
					'params'                    => array(
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'title',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'description' => esc_html__( 'Enter section title (Note: you can leave it empty).', 'cize' ),
                        ),
                        array(
                            'type'        => 'attach_image',
                            'param_name'  => 'image',
                            'heading'     => esc_html__( 'Image', 'cize' ),
                            'description' => esc_html__( 'Enter section image.', 'cize' ),
                        ),
						array(
							'type'        => 'el_id',
							'param_name'  => 'tab_id',
							'settings'    => array(
								'auto_generate' => true,
							),
							'heading'     => esc_html__( 'Section ID', 'cize' ),
							'description' => esc_html__( 'Enter section ID (Note: make sure it is unique and valid according to w3c specification.', 'cize' )
						),
						array(
							'type'        => 'checkbox',
							'param_name'  => 'add_icon',
							'heading'     => esc_html__( 'Add icon?', 'cize' ),
							'description' => esc_html__( 'Add icon next to section title.', 'cize' ),
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'i_position',
							'value'       => array(
								esc_html__( 'Before title', 'cize' ) => 'left',
								esc_html__( 'After title', 'cize' )  => 'right',
							),
							'dependency'  => array(
								'element' => 'add_icon',
								'value'   => 'true',
							),
							'heading'     => esc_html__( 'Icon position', 'cize' ),
							'description' => esc_html__( 'Select icon position.', 'cize' ),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Icon library', 'cize' ),
							'value'       => array(
								esc_html__( 'Font Awesome', 'cize' )  => 'fontawesome',
								esc_html__( 'Font Flaticon', 'cize' ) => 'fontflaticon',
							),
							'dependency'  => array(
								'element' => 'add_icon',
								'value'   => 'true',
							),
							'admin_label' => true,
							'param_name'  => 'i_type',
							'std'         => 'fontawesome',
							'description' => esc_html__( 'Select icon library.', 'cize' ),
						),
						array(
							'param_name'  => 'icon_cizecustomfonts',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
							'type'        => 'iconpicker',
							'settings'    => array(
								'emptyIcon' => true,
								'type'      => 'cizecustomfonts',
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontflaticon',
							),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'param_name'  => 'icon_fontawesome',
							'value'       => 'fa fa-adjust',
							// default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false,
								// default true, display an "EMPTY" icon?
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontawesome',
							),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'cize' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'cize' ),
						),
					),
					'js_view'                   => 'VcBackendTtaSectionView',
					'custom_markup'             => '
                    <div class="vc_tta-panel-heading">
                        <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="javascript:;" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">{{ section_title }}</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4>
                    </div>
                    <div class="vc_tta-panel-body">
                        {{ editor_controls }}
                        <div class="{{ container-class }}">
                        {{ content }}
                        </div>
                    </div>',
					'default_content'           => '',
				)
			);

			/*Map New section title */
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Section Title', 'cize' ),
					'base'        => 'cize_title',
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a custom title.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'section-title.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'title/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'title/style-02.jpg',
								),
                                'style-03' => array(
                                    'alt' => 'Style 03', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'title/style-03.jpg',
                                ),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The title of shortcode', 'cize' ),
							'admin_label' => true,
							'std'         => '',
						),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Description', 'cize' ),
                            'param_name'  => 'desc',
                            'description' => esc_html__( 'The description of shortcode', 'cize' ),
                            'std'         => '',
                            'dependency' => array(
                                'element' => 'style',
                                'value'   => array('style-01','style-02'),
                            ),
                        ),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'title_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			// Map new Tabs element.
			vc_map(
				array(
					'name'                    => esc_html__( 'Cize: Tabs', 'cize' ),
					'base'                    => 'cize_tabs',
					'icon'                    => CIZE_SHORTCODES_ICONS_URI . 'tabs.png',
					'is_container'            => true,
					'show_settings_on_create' => false,
					'as_parent'               => array(
						'only' => 'vc_tta_section',
					),
					'category'                => esc_html__( 'Cize Elements', 'cize' ),
					'description'             => esc_html__( 'Tabs content', 'cize' ),
					'params'                  => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01', //CIZE_SHORTCODE_PREVIEW
									'img' => CIZE_SHORTCODE_PREVIEW . 'tabs/style-01.jpg',
								),
                                'style-02' => array(
                                    'alt' => 'Style 02', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'tabs/style-02.jpg',
                                ),
                                'style-03' => array(
                                    'alt' => 'Style 03', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'tabs/style-03.jpg',
                                ),
                                'style-04' => array(
                                    'alt' => 'Style 04', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'tabs/style-04.jpg',
                                ),
                                'style-05' => array(
                                    'alt' => 'Style 05', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'tabs/style-05.jpg',
                                ),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title_tabs',
                            'description' => esc_html__( 'The title of shortcode', 'cize' ),
                            'admin_label' => true,
                            'std'         => '',
                        ),
                        array(
                            'type'       => 'vc_link',
                            'heading'    => esc_html__( 'Link', 'cize' ),
                            'param_name' => 'link',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array('style-03','style-04'),
                            ),
                        ),
						vc_map_add_css_animation(),
						array(
							'param_name' => 'ajax_check',
							'heading'    => esc_html__( 'Using Ajax Tabs', 'cize' ),
							'type'       => 'dropdown',
							'value'      => array(
								esc_html__( 'Yes', 'cize' ) => '1',
								esc_html__( 'No', 'cize' )  => '0',
							),
							'std'        => '0',
						),
						array(
							'type'       => 'textfield',
							'heading'    => esc_html__( 'Active Section', 'cize' ),
							'param_name' => 'active_section',
							'std'        => '1',
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'cize' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'cize' ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'CSS box', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'tabs_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
						array(
							'type'             => 'checkbox',
							'param_name'       => 'collapsible_all',
							'heading'          => esc_html__( 'Allow collapse all?', 'cize' ),
							'description'      => esc_html__( 'Allow collapse all accordion sections.', 'cize' ),
							'edit_field_class' => 'hidden',
						),
					),
					'js_view'                 => 'VcBackendTtaTabsView',
					'custom_markup'           => '
                    <div class="vc_tta-container" data-vc-action="collapse">
                        <div class="vc_general vc_tta vc_tta-tabs vc_tta-color-backend-tabs-white vc_tta-style-flat vc_tta-shape-rounded vc_tta-spacing-1 vc_tta-tabs-position-top vc_tta-controls-align-left">
                            <div class="vc_tta-tabs-container">'
					                             . '<ul class="vc_tta-tabs-list">'
					                             . '<li class="vc_tta-tab" data-vc-tab data-vc-target-model-id="{{ model_id }}" data-element_type="vc_tta_section"><a href="javascript:;" data-vc-tabs data-vc-container=".vc_tta" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-target-model-id="{{ model_id }}"><span class="vc_tta-title-text">{{ section_title }}</span></a></li>'
					                             . '</ul>
                            </div>
                            <div class="vc_tta-panels vc_clearfix {{container-class}}">
                              {{ content }}
                            </div>
                        </div>
                    </div>',
					'default_content'         => '
                        [vc_tta_section title="' . sprintf( '%s %d', esc_html__( 'Tab', 'cize' ), 1 ) . '"][/vc_tta_section]
                        [vc_tta_section title="' . sprintf( '%s %d', esc_html__( 'Tab', 'cize' ), 2 ) . '"][/vc_tta_section]
                    ',
					'admin_enqueue_js'        => array(
						vc_asset_url( 'lib/vc_tabs/vc-tabs.min.js' ),
					),
				)
			);

			// Map new Products
			// CUSTOM PRODUCT SIZE
			$product_size_width_list = array();
			$width                   = 300;
			$height                  = 300;
			$crop                    = 1;
            if ( function_exists( 'wc_get_image_size' ) ) {
                $size   = wc_get_image_size( 'shop_catalog' );
                $width  = isset( $size['width'] ) && is_numeric($size['width']) ? $size['width'] : $width;
                $height = isset( $size['height']) && is_numeric($size['height']) ? $size['height'] : $height;
                $crop   = isset( $size['crop'] ) ? $size['crop'] : $crop;
            }
			for ( $i = 100; $i < $width; $i = $i + 10 ) {
				array_push( $product_size_width_list, $i );
			}
			$product_size_list                           = array();
			$product_size_list[ $width . 'x' . $height ] = $width . 'x' . $height;
			foreach ( $product_size_width_list as $k => $w ) {
			    if(is_numeric($w)) {
                    $w = intval( $w );
                    if ( isset( $width ) && $width > 0 ) {
                        $h = round( $height * $w / $width );
                    } else {
                        $h = $w;
                    }
                    $product_size_list[ $w . 'x' . $h ] = $w . 'x' . $h;
                }
			}
			$product_size_list['Custom'] = 'custom';
			$attributes_tax              = array();
			if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
				$attributes_tax = wc_get_attribute_taxonomies();
			}

			$attributes = array();
			if ( is_array( $attributes_tax ) && count( $attributes_tax ) > 0 ) {
				foreach ( $attributes_tax as $attribute ) {
					$attributes[ $attribute->attribute_label ] = $attribute->attribute_name;
				}
			}
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Products', 'cize' ),
					'base'        => 'cize_products', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a product list or grid.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'product.png',
					'params'      => array(
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Product List style', 'cize' ),
							'param_name'  => 'productsliststyle',
							'value'       => array(
								esc_html__( 'Grid Bootstrap', 'cize' ) => 'grid',
								esc_html__( 'Owl Carousel', 'cize' )   => 'owl',
							),
							'description' => esc_html__( 'Select a style for list', 'cize' ),
							'admin_label' => true,
							'std'         => 'grid',
						),
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Product style', 'cize' ),
							'value'       => array(
								'1' => array(
									'alt' => esc_html__( 'Style 01', 'cize' ),
									'img' => CIZE_PRODUCT_STYLE_PREVIEW . 'content-product-style-1.jpg',
								),
								'2' => array(
									'alt' => esc_html__( 'Style 02', 'cize' ),
									'img' => CIZE_PRODUCT_STYLE_PREVIEW . 'content-product-style-2.jpg',
								),
								'3' => array(
									'alt' => esc_html__( 'Style 03', 'cize' ),
									'img' => CIZE_PRODUCT_STYLE_PREVIEW . 'content-product-style-3.jpg',
								),
								'4' => array(
									'alt' => esc_html__( 'Style 04', 'cize' ),
									'img' => CIZE_PRODUCT_STYLE_PREVIEW . 'content-product-style-4.jpg',
								),
                                '5' => array(
                                    'alt' => esc_html__( 'Style 05', 'cize' ),
                                    'img' => CIZE_PRODUCT_STYLE_PREVIEW . 'content-product-style-5.jpg',
                                ),
							),
							'default'     => '1',
							'admin_label' => true,
							'param_name'  => 'product_style',
							'description' => esc_html__( 'Select a style for product item', 'cize' ),
						),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'description' => esc_html__( 'The Title', 'cize' ),
                            'admin_label' => true,
                            'dependency'  => array(
                                'element' => 'product_style',
                                'value'   => array( '3'),
                            ),
                        ),
                        array(
                            'type'        => 'vc_link',
                            'heading'     => esc_html__( 'URL (Link)', 'cize' ),
                            'param_name'  => 'link',
                            'description' => esc_html__( 'Add link.', 'cize' ),
                            'dependency'  => array(
                                'element' => 'product_style',
                                'value'   => array( '3'),
                            ),
                        ),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Image size', 'cize' ),
							'param_name'  => 'product_image_size',
							'value'       => $product_size_list,
							'description' => esc_html__( 'Select a size for product', 'cize' ),
							'std'         => '320x387',
							'admin_label' => true,
						),
						array(
							"type"       => "textfield",
							"heading"    => esc_html__( "Width", 'cize' ),
							"param_name" => "product_custom_thumb_width",
							"value"      => $width,
							"suffix"     => esc_html__( "px", 'cize' ),
							"dependency" => array( "element" => "product_image_size", "value" => array( 'custom' ) ),
						),
						array(
							"type"       => "textfield",
							"heading"    => esc_html__( "Height", 'cize' ),
							"param_name" => "product_custom_thumb_height",
							"value"      => $height,
							"suffix"     => esc_html__( "px", 'cize' ),
							"dependency" => array( "element" => "product_image_size", "value" => array( 'custom' ) ),
						),
						/*Products */
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Target', 'cize' ),
							'param_name'  => 'target',
							'value'       => array(
								esc_html__( 'Best Selling Products', 'cize' ) => 'best-selling',
								esc_html__( 'Top Rated Products', 'cize' )    => 'top-rated',
								esc_html__( 'Recent Products', 'cize' )       => 'recent-product',
								esc_html__( 'Product Category', 'cize' )      => 'product-category',
								esc_html__( 'Products', 'cize' )              => 'products',
								esc_html__( 'Featured Products', 'cize' )     => 'featured_products',
								esc_html__( 'On Sale', 'cize' )               => 'on_sale',
								esc_html__( 'On New', 'cize' )                => 'on_new',
							),
							'description' => esc_html__( 'Choose the target to filter products', 'cize' ),
							'std'         => 'recent-product',
							'group'       => esc_html__( 'Products options', 'cize' ),
						),
                        array(
                            "type"        => "taxonomy",
                            "taxonomy"    => "product_cat",
                            "class"       => "",
                            "heading"     => esc_html__( "Product Category", 'cize' ),
                            "param_name"  => "taxonomy",
                            "value"       => '',
                            'parent'      => '',
                            'multiple'    => true,
                            'hide_empty'  => false,
                            'placeholder' => esc_html__( 'Choose category', 'cize' ),
                            "description" => esc_html__( "Note: If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'cize' ),
                            'std'         => '',
                            'group'       => esc_html__( 'Products options', 'cize' ),
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => esc_html__( 'Total items', 'cize' ),
                            'param_name' => 'per_page',
                            'value'      => 10,
                            "dependency" => array(
                                "element" => "target",
                                "value"   => array(
                                    'best-selling',
                                    'top-rated',
                                    'recent-product',
                                    'product-category',
                                    'featured_products',
                                    'product_attribute',
                                    'on_sale',
                                    'on_new'
                                )
                            ),
                            'group'       => esc_html__( 'Products options', 'cize' ),
                        ),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order by", 'cize' ),
							"param_name"  => "orderby",
							"value"       => array(
								'',
								esc_html__( 'Date', 'cize' )          => 'date',
								esc_html__( 'ID', 'cize' )            => 'ID',
								esc_html__( 'Author', 'cize' )        => 'author',
								esc_html__( 'Title', 'cize' )         => 'title',
								esc_html__( 'Modified', 'cize' )      => 'modified',
								esc_html__( 'Random', 'cize' )        => 'rand',
								esc_html__( 'Comment count', 'cize' ) => 'comment_count',
								esc_html__( 'Menu order', 'cize' )    => 'menu_order',
								esc_html__( 'Sale price', 'cize' )    => '_sale_price',
							),
							'std'         => 'date',
							"description" => esc_html__( "Select how to sort.", 'cize' ),
							"dependency"  => array(
								"element" => "target",
								"value"   => array(
									'top-rated',
									'recent-product',
									'product-category',
									'featured_products',
									'on_sale',
									'on_new',
									'product_attribute'
								)
							),
							'group'       => esc_html__( 'Products options', 'cize' ),
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order", 'cize' ),
							"param_name"  => "order",
							"value"       => array(
								esc_html__( 'ASC', 'cize' )  => 'ASC',
								esc_html__( 'DESC', 'cize' ) => 'DESC',
							),
							'std'         => 'DESC',
							"description" => esc_html__( "Designates the ascending or descending order.", 'cize' ),
							"dependency"  => array(
								"element" => "target",
								"value"   => array(
									'top-rated',
									'recent-product',
									'product-category',
									'featured_products',
									'on_sale',
									'on_new',
									'product_attribute'
								)
							),
							'group'       => esc_html__( 'Products options', 'cize' ),
						),
						array(
							'type'        => 'autocomplete',
							'heading'     => esc_html__( 'Products', 'cize' ),
							'param_name'  => 'ids',
							'settings'    => array(
								'multiple'      => true,
								'sortable'      => true,
								'unique_values' => true,
							),
							'save_always' => true,
							'description' => esc_html__( 'Enter List of Products', 'cize' ),
							"dependency"  => array( "element" => "target", "value" => array( 'products' ) ),
							'group'       => esc_html__( 'Products options', 'cize' ),
						),
						/* OWL Settings */
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( '1 Row', 'cize' )  => '1',
								esc_html__( '2 Rows', 'cize' ) => '2',
								esc_html__( '3 Rows', 'cize' ) => '3',
								esc_html__( '4 Rows', 'cize' ) => '4',
								esc_html__( '5 Rows', 'cize' ) => '5',
							),
							'std'         => '1',
							'heading'     => esc_html__( 'The number of rows which are shown on block', 'cize' ),
							'param_name'  => 'owl_number_row',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Rows space', 'cize' ),
							'param_name' => 'owl_rows_space',
							'value'      => array(
								esc_html__( 'Default', 'cize' ) => 'rows-space-0',
								esc_html__( '10px', 'cize' )    => 'rows-space-10',
								esc_html__( '20px', 'cize' )    => 'rows-space-20',
								esc_html__( '30px', 'cize' )    => 'rows-space-30',
								esc_html__( '40px', 'cize' )    => 'rows-space-40',
								esc_html__( '50px', 'cize' )    => 'rows-space-50',
								esc_html__( '60px', 'cize' )    => 'rows-space-60',
								esc_html__( '70px', 'cize' )    => 'rows-space-70',
								esc_html__( '80px', 'cize' )    => 'rows-space-80',
								esc_html__( '90px', 'cize' )    => 'rows-space-90',
								esc_html__( '100px', 'cize' )   => 'rows-space-100',
							),
							'std'        => 'rows-space-0',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							"dependency" => array(
								"element" => "owl_number_row",
								"value"   => array( '2', '3', '4', '5' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'AutoPlay', 'cize' ),
							'param_name'  => 'autoplay',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => false,
							'heading'     => esc_html__( 'Navigation', 'cize' ),
							'param_name'  => 'navigation',
							'description' => esc_html__( "Show buton 'next' and 'prev' buttons.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => false,
							'heading'     => esc_html__( 'Enable Dots', 'cize' ),
							'param_name'  => 'dots',
							'description' => esc_html__( "Show buton dots", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
                                esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => false,
							'heading'     => esc_html__( 'Loop', 'cize' ),
							'param_name'  => 'loop',
							'description' => esc_html__( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Slide Speed", 'cize' ),
							"param_name"  => "slidespeed",
							"value"       => "200",
							"suffix"      => esc_html__( "milliseconds", 'cize' ),
							"description" => esc_html__( 'Slide speed in milliseconds', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Margin", 'cize' ),
							"param_name"  => "margin",
							"value"       => "0",
							"description" => esc_html__( 'Distance( or space) between 2 item', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Auto Responsive Margin', 'cize' ),
							'param_name' => 'autoresponsive',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							'value'      => array(
								esc_html__( 'No', 'cize' )  => '',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'        => '',
							"dependency" => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1500px )", 'cize' ),
							"param_name"  => "ls_items",
							"value"       => "5",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1200px and < 1500px )", 'cize' ),
							"param_name"  => "lg_items",
							"value"       => "4",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 992px < 1200px )", 'cize' ),
							"param_name"  => "md_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on tablet (Screen resolution of device >=768px and < 992px )", 'cize' ),
							"param_name"  => "sm_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile landscape(Screen resolution of device >=480px and < 768px)", 'cize' ),
							"param_name"  => "xs_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile (Screen resolution of device < 480px)", 'cize' ),
							"param_name"  => "ts_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'owl' ),
							),
						),
						/* Bostrap setting */
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Rows space', 'cize' ),
							'param_name' => 'boostrap_rows_space',
							'value'      => array(
								esc_html__( 'Default', 'cize' ) => 'rows-space-0',
								esc_html__( '10px', 'cize' )    => 'rows-space-10',
								esc_html__( '20px', 'cize' )    => 'rows-space-20',
								esc_html__( '30px', 'cize' )    => 'rows-space-30',
								esc_html__( '40px', 'cize' )    => 'rows-space-40',
								esc_html__( '50px', 'cize' )    => 'rows-space-50',
								esc_html__( '60px', 'cize' )    => 'rows-space-60',
								esc_html__( '70px', 'cize' )    => 'rows-space-70',
								esc_html__( '80px', 'cize' )    => 'rows-space-80',
								esc_html__( '90px', 'cize' )    => 'rows-space-90',
								esc_html__( '100px', 'cize' )   => 'rows-space-100',
							),
							'std'        => 'rows-space-0',
							'group'      => esc_html__( 'Boostrap settings', 'cize' ),
							"dependency" => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on Desktop', 'cize' ),
							'param_name'  => 'boostrap_bg_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device >= 1500px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '15',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on Desktop', 'cize' ),
							'param_name'  => 'boostrap_lg_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device >= 1200px and < 1500px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '3',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on landscape tablet', 'cize' ),
							'param_name'  => 'boostrap_md_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device >=992px and < 1200px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '3',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on portrait tablet', 'cize' ),
							'param_name'  => 'boostrap_sm_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device >=768px and < 992px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '4',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on Mobile', 'cize' ),
							'param_name'  => 'boostrap_xs_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device >=480  add < 768px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '6',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Items per row on Mobile', 'cize' ),
							'param_name'  => 'boostrap_ts_items',
							'value'       => array(
								esc_html__( '1 item', 'cize' )  => '12',
								esc_html__( '2 items', 'cize' ) => '6',
								esc_html__( '3 items', 'cize' ) => '4',
								esc_html__( '4 items', 'cize' ) => '3',
								esc_html__( '5 items', 'cize' ) => '15',
								esc_html__( '6 items', 'cize' ) => '2',
							),
							'description' => esc_html__( '(Item per row on screen resolution of device < 480px)', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							"dependency"  => array(
								"element" => "productsliststyle",
								"value"   => array( 'grid' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'products_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Deal Product', 'cize' ),
					'base'        => 'cize_dealproduct', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display deal product.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'product.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Style', 'cize' ),
							'value'       => array(
								'01' => array(
									'alt' => esc_html__( 'Style 01', 'cize' ),
									'img' => CIZE_PRODUCT_DEAL_PREVIEW . 'content-product-style-01.jpg',
								),
								'02' => array(
									'alt' => esc_html__( 'Style 02', 'cize' ),
									'img' => CIZE_PRODUCT_DEAL_PREVIEW . 'content-product-style-02.jpg',
								),
                                '03' => array(
                                    'alt' => esc_html__( 'Style 03', 'cize' ),
                                    'img' => CIZE_PRODUCT_DEAL_PREVIEW . 'content-product-style-03.jpg',
                                ),
							),
							'default'     => '01',
							'admin_label' => true,
							'param_name'  => 'style',
							'description' => esc_html__( 'Select a style for product item', 'cize' ),
						),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => esc_html__( 'Icon library', 'cize' ),
                            'value'       => array(
                                esc_html__( 'Font Awesome', 'cize' )  => 'fontawesome',
                                esc_html__( 'Font Flaticon', 'cize' ) => 'fontflaticon',
                            ),
                            'param_name'  => 'i_type',
                            'description' => esc_html__( 'Select icon library.', 'cize' ),
                            'std'         => 'fontawesome',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '03' ),
                            ),
                        ),
                        array(
                            'param_name'  => 'icon_cizecustomfonts',
                            'heading'     => esc_html__( 'Icon', 'cize' ),
                            'description' => esc_html__( 'Select icon from library.', 'cize' ),
                            'type'        => 'iconpicker',
                            'settings'    => array(
                                'emptyIcon' => true,
                                'type'      => 'cizecustomfonts',
                            ),
                            'dependency'  => array(
                                'element' => 'i_type',
                                'value'   => 'fontflaticon',
                            ),
                        ),
                        array(
                            'type'        => 'iconpicker',
                            'heading'     => esc_html__( 'Icon', 'cize' ),
                            'param_name'  => 'icon_fontawesome',
                            'value'       => 'fa fa-adjust',
                            'settings'    => array(
                                'emptyIcon'    => false,
                                'iconsPerPage' => 4000,
                            ),
                            'dependency'  => array(
                                'element' => 'i_type',
                                'value'   => 'fontawesome',
                            ),
                            'description' => esc_html__( 'Select icon from library.', 'cize' ),
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'description' => esc_html__( 'The title of shortcode', 'cize' ),
                            'std'         => '',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '01','03' ),
                            ),
                        ),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Image size', 'cize' ),
							'param_name'  => 'product_image_size',
							'value'       => $product_size_list,
							'description' => esc_html__( 'Select a size for product', 'cize' ),
							'std'         => '320x320',
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array('01'),
                            ),
						),
						array(
							"type"       => "textfield",
							"heading"    => esc_html__( "Width", 'cize' ),
							"param_name" => "product_custom_thumb_width",
							"value"      => $width,
							"suffix"     => esc_html__( "px", 'cize' ),
							"dependency" => array( "element" => "product_image_size", "value" => array( 'custom' ) ),
						),
						array(
							"type"       => "textfield",
							"heading"    => esc_html__( "Height", 'cize' ),
							"param_name" => "product_custom_thumb_height",
							"value"      => $height,
							"suffix"     => esc_html__( "px", 'cize' ),
							"dependency" => array( "element" => "product_image_size", "value" => array( 'custom' ) ),
						),
						/*Products */
                        array(
                            "type"       => "attach_image",
                            "heading"    => esc_html__( "Image custom", "cize" ),
                            "param_name" => "image",
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '02','03' )
                            ),
                        ),
						array(
							'type'        => 'autocomplete',
							'heading'     => esc_html__( 'Products', 'cize' ),
							'param_name'  => 'ids',
							'settings'    => array(
								'multiple'      => false,
								'sortable'      => true,
								'unique_values' => true,
							),
							'save_always' => true,
							'description' => esc_html__( 'Enter List of Products', 'cize' ),
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '02','03' )
                            ),
						),
						array(
							'type'       => 'textfield',
							'heading'    => esc_html__( 'Total items', 'cize' ),
							'param_name' => 'per_page',
							'value'      => 7,
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array('01')
                            ),
						),
						array(
							"type"        => "taxonomy",
							"taxonomy"    => "product_cat",
							"class"       => "",
							"heading"     => esc_html__( "Product Category", 'cize' ),
							"param_name"  => "taxonomy",
							"value"       => '',
							'parent'      => '',
							'multiple'    => true,
							'hide_empty'  => false,
							'placeholder' => esc_html__( 'Choose category', 'cize' ),
							"description" => esc_html__( "Note: If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'cize' ),
							'std'         => '',
							'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '01' )
							),
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order by", 'cize' ),
							"param_name"  => "orderby",
							"value"       => array(
								'',
								esc_html__( 'Date', 'cize' )          => 'date',
								esc_html__( 'ID', 'cize' )            => 'ID',
								esc_html__( 'Author', 'cize' )        => 'author',
								esc_html__( 'Title', 'cize' )         => 'title',
								esc_html__( 'Modified', 'cize' )      => 'modified',
								esc_html__( 'Random', 'cize' )        => 'rand',
								esc_html__( 'Comment count', 'cize' ) => 'comment_count',
								esc_html__( 'Menu order', 'cize' )    => 'menu_order',
								esc_html__( 'Sale price', 'cize' )    => '_sale_price',
							),
							'std'         => 'date',
							"description" => esc_html__( "Select how to sort.", 'cize' ),
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '01' )
                            ),
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Order", 'cize' ),
							"param_name"  => "order",
							"value"       => array(
								esc_html__( 'ASC', 'cize' )  => 'ASC',
								esc_html__( 'DESC', 'cize' ) => 'DESC',
							),
							'std'         => 'DESC',
							"description" => esc_html__( "Designates the ascending or descending order.", 'cize' ),
                            'dependency'  => array(
                                'element' => 'style',
                                'value'   => array( '01' )
                            ),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => '',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
                        ),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'dealproduct_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			/* Instagram */
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Instagram', 'cize' ),
					'base'        => 'cize_instagram', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a instagram photo list.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'instagram.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'instagram/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02',
									'img' => CIZE_SHORTCODE_PREVIEW . 'instagram/style-02.jpg',
								),
								'style-03' => array(
									'alt' => 'Style 03',
									'img' => CIZE_SHORTCODE_PREVIEW . 'instagram/style-03.jpg',
								),
								'style-04' => array(
									'alt' => 'Style 04',
									'img' => CIZE_SHORTCODE_PREVIEW . 'instagram/style-04.jpg',
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Choose icon or image', 'cize' ),
							'value'      => array(
								esc_html__( 'No use', 'cize' ) => '',
								esc_html__( 'Icon', 'cize' )   => 'icontype',
								esc_html__( 'Image', 'cize' )  => 'imagetype',
							),
							'param_name' => 'iconimage',
							'std'        => '',
						),
						array(
							"type"       => "attach_image",
							"heading"    => esc_html__( "Image custom", "cize" ),
							"param_name" => "image",
							'dependency' => array(
								'element' => 'iconimage',
								'value'   => 'imagetype',
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Icon library', 'cize' ),
							'value'       => array(
								esc_html__( 'Font Awesome', 'cize' )  => 'fontawesome',
								esc_html__( 'Font Flaticon', 'cize' ) => 'fontflaticon',
							),
							'admin_label' => true,
							'param_name'  => 'i_type',
							'description' => esc_html__( 'Select icon library.', 'cize' ),
							'std'         => 'fontawesome',
							'dependency'  => array(
								'element' => 'iconimage',
								'value'   => 'icontype',
							),
						),
						array(
							'param_name'  => 'icon_cizecustomfonts',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
							'type'        => 'iconpicker',
							'settings'    => array(
								'emptyIcon' => true,
								'type'      => 'cizecustomfonts',
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontflaticon',
							),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => esc_html__( 'Icon', 'cize' ),
							'param_name'  => 'icon_fontawesome',
							'value'       => 'fa fa-adjust',
							'settings'    => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'  => array(
								'element' => 'i_type',
								'value'   => 'fontawesome',
							),
							'description' => esc_html__( 'Select icon from library.', 'cize' ),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The title of shortcode', 'cize' ),
							'admin_label' => true,
							'std'         => '',
						),
						array(
							'type'       => 'textarea_html',
							'heading'    => esc_html__( 'Description', 'cize' ),
							'param_name' => 'content',
							'std'        => '',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Images limit', 'cize' ),
							'param_name'  => 'limit',
							'std'         => '6',
							'admin_label' => true,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Instagram user ID', 'cize' ),
							'param_name'  => 'id',
							'admin_label' => true,
							'description' => esc_html__( 'Your Instagram ID. Ex: 2267639447. ', 'cize' ) . '<a href="http://instagram.pixelunion.net/" target="_blank">' . esc_html__( 'How to find?', 'cize' ) . '</a>',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Access token', 'cize' ),
							'param_name'  => 'token',
							'description' => esc_html__( 'Your Instagram token. Ex: 2267639447.1677ed0.eade9f2bbe8245ea8bdedab984f3b4c3. ', 'cize' ) . '<a href="http://instagram.pixelunion.net/" target="_blank">' . esc_html__( 'How to find?', 'cize' ) . '</a>',
							'admin_label' => true,
						),
						/* Owl */
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( '1 Row', 'cize' )  => '1',
								esc_html__( '2 Rows', 'cize' ) => '2',
								esc_html__( '3 Rows', 'cize' ) => '3',
								esc_html__( '4 Rows', 'cize' ) => '4',
								esc_html__( '5 Rows', 'cize' ) => '5',
							),
							'std'         => '1',
							'heading'     => esc_html__( 'The number of rows which are shown on block', 'cize' ),
							'param_name'  => 'owl_number_row',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Rows space', 'cize' ),
							'param_name' => 'owl_rows_space',
							'value'      => array(
								esc_html__( 'Default', 'cize' ) => 'rows-space-0',
								esc_html__( '10px', 'cize' )    => 'rows-space-10',
								esc_html__( '20px', 'cize' )    => 'rows-space-20',
								esc_html__( '30px', 'cize' )    => 'rows-space-30',
								esc_html__( '40px', 'cize' )    => 'rows-space-40',
								esc_html__( '50px', 'cize' )    => 'rows-space-50',
								esc_html__( '60px', 'cize' )    => 'rows-space-60',
								esc_html__( '70px', 'cize' )    => 'rows-space-70',
								esc_html__( '80px', 'cize' )    => 'rows-space-80',
								esc_html__( '90px', 'cize' )    => 'rows-space-90',
								esc_html__( '100px', 'cize' )   => 'rows-space-100',
							),
							'std'        => 'rows-space-0',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							"dependency" => array(
								"element" => "owl_number_row",
								"value"   => array( '2', '3', '4', '5' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false'
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'AutoPlay', 'cize' ),
							'param_name'  => 'autoplay',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Navigation', 'cize' ),
							'param_name'  => 'navigation',
							'description' => esc_html__( "Show buton 'next' and 'prev' buttons.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Enable Dots', 'cize' ),
							'param_name'  => 'dots',
							'description' => esc_html__( "Show buton dots.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false'
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Loop', 'cize' ),
							'param_name'  => 'loop',
							'description' => esc_html__( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Slide Speed", 'cize' ),
							"param_name"  => "slidespeed",
							"value"       => "200",
							"description" => esc_html__( 'Slide speed in milliseconds', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Margin", 'cize' ),
							"param_name"  => "margin",
							"value"       => "30",
							"description" => esc_html__( 'Distance( or space) between 2 item', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Auto Responsive Margin', 'cize' ),
							'param_name' => 'autoresponsive',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							'value'      => array(
								esc_html__( 'No', 'cize' )  => '',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'        => '',
							'dependency' => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1500px )", 'cize' ),
							"param_name"  => "ls_items",
							"value"       => "5",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1200px )", 'cize' ),
							"param_name"  => "lg_items",
							"value"       => "4",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 992px < 1200px )", 'cize' ),
							"param_name"  => "md_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on tablet (Screen resolution of device >=768px and < 992px )", 'cize' ),
							"param_name"  => "sm_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile landscape(Screen resolution of device >=480px and < 768px)", 'cize' ),
							"param_name"  => "xs_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile (Screen resolution of device < 480px)", 'cize' ),
							"param_name"  => "ts_items",
							"value"       => "1",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( 'style-01', 'style-04' ),
							),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" )
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'instagram_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						)
					)
				)
			);


			/*Map new Container */
			vc_map(
				array(
					'name'                    => esc_html__( 'Cize: Container', 'cize' ),
					'base'                    => 'cize_container',
					'category'                => esc_html__( 'Cize Elements', 'cize' ),
					'content_element'         => true,
					'show_settings_on_create' => true,
					'is_container'            => true,
					'js_view'                 => 'VcColumnView',
					'icon'                    => CIZE_SHORTCODES_ICONS_URI . 'container.png',
					'params'                  => array(
						array(
							'param_name'  => 'content_width',
							'heading'     => esc_html__( 'Content width', 'cize' ),
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Default', 'cize' )         => 'container',
								esc_html__( 'Custom Boostrap', 'cize' ) => 'custom_col',
								esc_html__( 'Custom Width', 'cize' )    => 'custom_width',
							),
							'admin_label' => true,
							'std'         => 'container',
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on Desktop', 'cize' ),
							'param_name'  => 'boostrap_bg_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device >= 1500px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '15',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on Desktop', 'cize' ),
							'param_name'  => 'boostrap_lg_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device >= 1200px and < 1500px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on landscape tablet', 'cize' ),
							'param_name'  => 'boostrap_md_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device >=992px and < 1200px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on portrait tablet', 'cize' ),
							'param_name'  => 'boostrap_sm_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device >=768px and < 992px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on Mobile', 'cize' ),
							'param_name'  => 'boostrap_xs_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device >=480  add < 768px )', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Percent width row on Mobile', 'cize' ),
							'param_name'  => 'boostrap_ts_items',
							'value'       => array(
								esc_html__( '12 column - 12/12', 'cize' ) => '12',
								esc_html__( '11 column - 11/12', 'cize' ) => '11',
								esc_html__( '10 column - 10/12', 'cize' ) => '10',
								esc_html__( '9 column - 9/12', 'cize' )   => '9',
								esc_html__( '8 column - 8/12', 'cize' )   => '8',
								esc_html__( '7 column - 7/12', 'cize' )   => '7',
								esc_html__( '6 column - 6/12', 'cize' )   => '6',
								esc_html__( '5 column - 5/12', 'cize' )   => '5',
								esc_html__( '4 column - 4/12', 'cize' )   => '4',
								esc_html__( '3 column - 3/12', 'cize' )   => '3',
								esc_html__( '2 column - 2/12', 'cize' )   => '2',
								esc_html__( '1 column - 1/12', 'cize' )   => '1',
								esc_html__( '1 column 5 - 1/5', 'cize' )  => '15',
								esc_html__( '4 column 5 - 4/5', 'cize' )  => '45',
							),
							'description' => esc_html__( '(Percent width row on screen resolution of device < 480px)', 'cize' ),
							'group'       => esc_html__( 'Boostrap settings', 'cize' ),
							'std'         => '12',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_col' ),
							),
						),
						array(
							'param_name'  => 'number_width',
							'heading'     => esc_html__( 'width', 'cize' ),
							"description" => esc_html__( "you can width by px or %, ex: 100%", "cize" ),
							'std'         => '50%',
							'admin_label' => true,
							'type'        => 'textfield',
							'dependency'  => array(
								'element' => 'content_width',
								'value'   => array( 'custom_width' ),
							),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'param_name'       => 'container_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);

			/*Map New Newsletter*/
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Newsletter', 'cize' ),
					'base'        => 'cize_newsletter', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a newsletter box.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'newllter.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select Style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'newsletter/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02',
									'img' => CIZE_SHORTCODE_PREVIEW . 'newsletter/style-02.jpg',
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Title', 'cize' ),
							'param_name'  => 'title',
							'description' => esc_html__( 'The title of shortcode', 'cize' ),
							'admin_label' => true,
							'std'         => '',
						),
						array(
							'type'       => 'textfield',
							'heading'    => esc_html__( 'Description', 'cize' ),
							'param_name' => 'description',
							'std'        => '',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Placeholder text", 'cize' ),
							"param_name"  => "placeholder_text",
							"admin_label" => false,
							'std'         => 'Your email address...',
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'newsletter_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
            /*Map New section title */
            vc_map(
                array(
                    'name'        => esc_html__( 'Cize: Section Search', 'cize' ),
                    'base'        => 'cize_search',
                    'class'       => '',
                    'category'    => esc_html__( 'Cize Elements', 'cize' ),
                    'description' => esc_html__( 'Display a custom search.', 'cize' ),
                    'icon'        => CIZE_SHORTCODES_ICONS_URI . 'section-title.png',
                    'params'      => array(
                        array(
                            'type'        => 'select_preview',
                            'heading'     => esc_html__( 'Select style', 'cize' ),
                            'value'       => array(
                                'style-01' => array(
                                    'alt' => 'Style 01', //CIZE_SHORTCODE_PREVIEW
                                    'img' => CIZE_SHORTCODE_PREVIEW . 'search/style-01.jpg',
                                ),
                            ),
                            'default'     => 'style-01',
                            'admin_label' => true,
                            'param_name'  => 'style',
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'description' => esc_html__( 'The title of shortcode', 'cize' ),
                            'admin_label' => true,
                            'std'         => '',
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Placeholder', 'cize' ),
                            'param_name'  => 'placeholder',
                            'description' => esc_html__( 'The Placeholder of shortcode', 'cize' ),
                            'admin_label' => true,
                            'std'         => '',
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'animate_on_scroll',
                            'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
                            'value'      => $this->animation_on_scroll(),
                            'std'        => ''
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => esc_html__( "Extra class name", "cize" ),
                            "param_name"  => "el_class",
                            "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
                        ),
                        array(
                            'type'       => 'css_editor',
                            'heading'    => esc_html__( 'Css', 'cize' ),
                            'param_name' => 'css',
                            'group'      => esc_html__( 'Design Options', 'cize' ),
                        ),
                        array(
                            'param_name'       => 'search_custom_id',
                            'heading'          => esc_html__( 'Hidden ID', 'cize' ),
                            'type'             => 'uniqid',
                            'edit_field_class' => 'hidden',
                        ),
                    ),
                )
            );
			/*Map New Slider*/
			vc_map(
				array(
					'name'                    => esc_html__( 'Cize: Slider', 'cize' ),
					'base'                    => 'cize_slider',
					'category'                => esc_html__( 'Cize Elements', 'cize' ),
					'description'             => esc_html__( 'Display a custom slide.', 'cize' ),
					'as_parent'               => array( 'only' => 'vc_single_image,cize_banner,cize_iconbox,cize_testimonials' ),
					'content_element'         => true,
					'show_settings_on_create' => true,
					'js_view'                 => 'VcColumnView',
					'icon'                    => CIZE_SHORTCODES_ICONS_URI . 'slide.png',
					'params'                  => array(
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'admin_label' => true,
                        ),
						/* Owl */
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'AutoPlay', 'cize' ),
							'param_name'  => 'autoplay',
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Navigation', 'cize' ),
							'param_name'  => 'navigation',
							'description' => esc_html__( "Show buton 'next' and 'prev' buttons.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'No', 'cize' )  => 'false',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Enable Dots', 'cize' ),
							'param_name'  => 'dots',
							'description' => esc_html__( "Show buton dots.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'        => 'dropdown',
							'value'       => array(
								esc_html__( 'Yes', 'cize' ) => 'true',
								esc_html__( 'No', 'cize' )  => 'false',
							),
							'std'         => 'false',
							'heading'     => esc_html__( 'Loop', 'cize' ),
							'param_name'  => 'loop',
							'description' => esc_html__( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Slide Speed", 'cize' ),
							"param_name"  => "slidespeed",
							"value"       => "200",
							"description" => esc_html__( 'Slide speed in milliseconds', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Margin", 'cize' ),
							"param_name"  => "margin",
							"value"       => "30",
							"description" => esc_html__( 'Distance( or space) between 2 item', 'cize' ),
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Auto Responsive Margin', 'cize' ),
							'param_name' => 'autoresponsive',
							'group'      => esc_html__( 'Carousel settings', 'cize' ),
							'value'      => array(
								esc_html__( 'No', 'cize' )  => '',
								esc_html__( 'Yes', 'cize' ) => 'true',
							),
							'std'        => '',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1500px )", 'cize' ),
							"param_name"  => "ls_items",
							"value"       => "5",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 1200px < 1500px )", 'cize' ),
							"param_name"  => "lg_items",
							"value"       => "4",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on desktop (Screen resolution of device >= 992px < 1200px )", 'cize' ),
							"param_name"  => "md_items",
							"value"       => "3",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on tablet (Screen resolution of device >=768px and < 992px )", 'cize' ),
							"param_name"  => "sm_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile landscape(Screen resolution of device >=480px and < 768px)", 'cize' ),
							"param_name"  => "xs_items",
							"value"       => "2",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "The items on mobile (Screen resolution of device < 480px)", 'cize' ),
							"param_name"  => "ts_items",
							"value"       => "1",
							'group'       => esc_html__( 'Carousel settings', 'cize' ),
							'admin_label' => false,
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							'heading'     => esc_html__( 'Extra Class Name', 'cize' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cize' ),
							'type'        => 'textfield',
							'param_name'  => 'el_class',
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'slider_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);
			/*Section Testimonial*/
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Testimonial', 'cize' ),
					'base'        => 'cize_testimonials', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display testimonial info.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'testimonial.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select Style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'testimonial/style-01.jpg'
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Star Rating', 'cize' ),
							'param_name' => 'rating',
							'value'      => array(
								esc_html__( '1 Star', 'cize' )  => 'rating-1',
								esc_html__( '2 Stars', 'cize' ) => 'rating-2',
								esc_html__( '3 Stars', 'cize' ) => 'rating-3',
								esc_html__( '4 Stars', 'cize' ) => 'rating-4',
								esc_html__( '5 Stars', 'cize' ) => 'rating-5',
							),
							'std'        => 'rating-5',
						),
						array(
							'type'       => 'textarea',
							'heading'    => esc_html__( 'Content', 'cize' ),
							'param_name' => 'desc',
						),
                        array(
                            'type'       => 'attach_image',
                            'heading'    => esc_html__( 'Image', 'cize' ),
                            'param_name' => 'image',
                        ),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Name', 'cize' ),
							'param_name'  => 'name',
							'description' => esc_html__( 'Name', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Position', 'cize' ),
							'param_name'  => 'position',
							'description' => esc_html__( 'Position', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'       => 'vc_link',
							'heading'    => esc_html__( 'Link', 'cize' ),
							'param_name' => 'link',
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" )
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'testimonials_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						)
					)
				)
			);
			/*Section Team*/
			require_once vc_path_dir( 'CONFIG_DIR', 'content/vc-icon-element.php' );
			$icon_params = array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Link Social', 'cize' ),
					'param_name'  => 'link_social',
					'admin_label' => true,
					'description' => esc_html__( 'shortcode title.', 'cize' ),
				),
			);
			$icon_params = array_merge( $icon_params, (array) vc_map_integrate_shortcode(
				vc_icon_element_params(), 'i_', '',
				array(
					// we need only type, icon_fontawesome, icon_.., NOT color and etc
					'include_only_regex' => '/^(type|icon_\w*)/',
				)
			)
			);
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Team', 'cize' ),
					'base'        => 'cize_team', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display team info.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'testimonial.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select Style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'team/style-01.jpg'
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
						array(
							'type'       => 'attach_image',
							'heading'    => esc_html__( 'Image', 'cize' ),
							'param_name' => 'image',
						),
						array(
							'type'       => 'param_group',
							'heading'    => esc_html__( 'Social', 'cize' ),
							'param_name' => 'social_team',
							'params'     => $icon_params,
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Name', 'cize' ),
							'param_name'  => 'name',
							'description' => esc_html__( 'Name', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Position', 'cize' ),
							'param_name'  => 'position',
							'description' => esc_html__( 'Position', 'cize' ),
							'admin_label' => true,
						),
						array(
							'type'       => 'vc_link',
							'heading'    => esc_html__( 'Link', 'cize' ),
							'param_name' => 'link',
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" )
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'team_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						)
					)
				)
			);
			/* Map Google Map */
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Google Map', 'cize' ),
					'base'        => 'cize_googlemap', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a google map.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'gmap.png',
					'params'      => array(
						array(
							"type"        => "attach_image",
							"heading"     => esc_html__( "Pin", "cize" ),
							"param_name"  => "pin_icon",
							"admin_label" => false,
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Title", 'cize' ),
							"param_name"  => "title",
							'admin_label' => true,
							"description" => esc_html__( "title.", 'cize' ),
							'std'         => 'Fami themes',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Phone", 'cize' ),
							"param_name"  => "phone",
							'admin_label' => true,
							"description" => esc_html__( "phone.", 'cize' ),
							'std'         => '088-465 9965 02',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Email", 'cize' ),
							"param_name"  => "email",
							'admin_label' => true,
							"description" => esc_html__( "email.", 'cize' ),
							'std'         => 'famithemes@gmail.com',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Map Height", 'cize' ),
							"param_name"  => "map_height",
							'admin_label' => true,
							'std'         => '400',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Maps type', 'cize' ),
							'param_name' => 'map_type',
							'value'      => array(
								esc_html__( 'ROADMAP', 'cize' )   => 'ROADMAP',
								esc_html__( 'SATELLITE', 'cize' ) => 'SATELLITE',
								esc_html__( 'HYBRID', 'cize' )    => 'HYBRID',
								esc_html__( 'TERRAIN', 'cize' )   => 'TERRAIN',
							),
							'std'        => 'ROADMAP',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Show info content?', 'cize' ),
							'param_name' => 'info_content',
							'value'      => array(
								esc_html__( 'Yes', 'cize' ) => '1',
								esc_html__( 'No', 'cize' )  => '2',
							),
							'std'        => '1',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Address", 'cize' ),
							"param_name"  => "address",
							'admin_label' => true,
							"description" => esc_html__( "address.", 'cize' ),
							'std'         => 'New York City, NY, USA',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Longitude", 'cize' ),
							"param_name"  => "longitude",
							'admin_label' => true,
							"description" => esc_html__( "longitude.", 'cize' ),
							'std'         => '-73.935242',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Latitude", 'cize' ),
							"param_name"  => "latitude",
							'admin_label' => true,
							"description" => esc_html__( "latitude.", 'cize' ),
							'std'         => '40.730610',
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Zoom", 'cize' ),
							"param_name"  => "zoom",
							'admin_label' => true,
							"description" => esc_html__( "zoom.", 'cize' ),
							'std'         => '14',
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", 'cize' ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'googlemap_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);

			/* Map New Social */
			$socials     = array();
			$all_socials = cize_get_option( 'user_all_social' );
			$i           = 1;
			if ( $all_socials ) {
				foreach ( $all_socials as $social ) {
					$socials[ $social['title_social'] ] = $i ++;
				}
			}
			vc_map(
				array(
					'name'        => esc_html__( 'Cize: Socials', 'cize' ),
					'base'        => 'cize_socials', // shortcode
					'class'       => '',
					'category'    => esc_html__( 'Cize Elements', 'cize' ),
					'description' => esc_html__( 'Display a social list.', 'cize' ),
					'icon'        => CIZE_SHORTCODES_ICONS_URI . 'socials.png',
					'params'      => array(
						array(
							'type'        => 'select_preview',
							'heading'     => esc_html__( 'Select style', 'cize' ),
							'value'       => array(
								'style-01' => array(
									'alt' => 'Style 01',
									'img' => CIZE_SHORTCODE_PREVIEW . 'socials/style-01.jpg',
								),
								'style-02' => array(
									'alt' => 'Style 02',
									'img' => CIZE_SHORTCODE_PREVIEW . 'socials/style-02.jpg',
								),
							),
							'default'     => 'style-01',
							'admin_label' => true,
							'param_name'  => 'style',
						),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'cize' ),
                            'param_name'  => 'title',
                            'admin_label' => true,
                        ),
						array(
							'type'       => 'checkbox',
							'heading'    => esc_html__( 'Display on', 'cize' ),
							'param_name' => 'use_socials',
							'class'      => 'checkbox-display-block',
							'value'      => $socials,
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							"type"        => "textfield",
							"heading"     => esc_html__( "Extra class name", "cize" ),
							"param_name"  => "el_class",
							"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "cize" ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'Css', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),
						array(
							'param_name'       => 'socials_custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
					),
				)
			);

			/* Pin Mapper */
			$all_pin_mappers      = get_posts(
				array(
					'post_type'      => 'cize_mapper',
					'posts_per_page' => '-1'
				)
			);
			$all_pin_mappers_args = array(
				esc_html__( ' ---- Choose a pin mapper ---- ', 'cize' ) => '0',
			);
			if ( ! empty( $all_pin_mappers ) ) {
				foreach ( $all_pin_mappers as $pin_mapper ) {
					$all_pin_mappers_args[ $pin_mapper->post_title ] = $pin_mapper->ID;
				}
			} else {
				$all_pin_mappers_args = array(
					esc_html__( ' ---- No pin mapper to choose ---- ', 'cize' ) => '0',
				);
			}
			vc_map(
				array(
					'name'     => esc_html__( 'Cize: Pin Mapper', 'cize' ),
					'base'     => 'cize_pinmap',
					'category' => esc_html__( 'Cize Elements', 'cize' ),
					'icon'     => CIZE_SHORTCODES_ICONS_URI . 'pinmapper.png',
					'params'   => array(
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Choose Pin Mapper', 'cize' ),
							'param_name' => 'ids',
							'value'      => $all_pin_mappers_args
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'animate_on_scroll',
							'heading'    => esc_html__( 'Animation On Scroll', 'cize' ),
							'value'      => $this->animation_on_scroll(),
							'std'        => ''
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'cize' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'cize' ),
						),
						array(
							'param_name'       => 'custom_id',
							'heading'          => esc_html__( 'Hidden ID', 'cize' ),
							'type'             => 'uniqid',
							'edit_field_class' => 'hidden',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Show info content?', 'cize' ),
							'param_name' => 'show_info_content',
							'value'      => array(
								esc_html__( 'Yes', 'cize' ) => 'yes',
								esc_html__( 'No', 'cize' )  => 'no',
							),
							'std'        => 'no',
							'group'      => esc_html__( 'Info Text', 'cize' ),
						),
						array(
							'type'       => 'textarea',
							'heading'    => esc_html__( 'Title', 'cize' ),
							'param_name' => 'title',
							'dependency' => array(
								'element' => 'show_info_content',
								'value'   => array( 'yes' ),
							),
							'group'      => esc_html__( 'Info Text', 'cize' ),
						),
						array(
							'type'        => 'textarea',
							'heading'     => esc_html__( 'Short Description', 'cize' ),
							'param_name'  => 'short_desc',
							'description' => esc_html__( 'Short description display under the title', 'cize' ),
							'admin_label' => true,
							'std'         => '',
							'dependency'  => array(
								'element' => 'show_info_content',
								'value'   => array( 'yes' ),
							),
							'group'       => esc_html__( 'Info Text', 'cize' ),
						),
						array(
							'type'       => 'vc_link',
							'heading'    => esc_html__( 'Button Link', 'cize' ),
							'param_name' => 'btn_link',
							'dependency' => array(
								'element' => 'show_info_content',
								'value'   => array( 'yes' ),
							),
							'group'      => esc_html__( 'Info Text', 'cize' ),
						),
						array(
							'type'        => 'textfield',
							'holder'      => 'div',
							'class'       => '',
							'heading'     => esc_html__( 'Position', 'cize' ),
							'param_name'  => 'pos',
							'std'         => '200:800',
							'description' => esc_html__( '{top}:{left}. Example: 200:800, etc...', 'cize' ),
							'dependency'  => array(
								'element' => 'show_info_content',
								'value'   => array( 'yes' ),
							),
							'group'       => esc_html__( 'Info Text', 'cize' ),
						),
						array(
							'type'       => 'css_editor',
							'heading'    => esc_html__( 'CSS box', 'cize' ),
							'param_name' => 'css',
							'group'      => esc_html__( 'Design Options', 'cize' ),
						),

					),
				)
			);

		}
	}

	new Cize_Visual_Composer();
}

if ( class_exists( 'Vc_Manager' ) ) {
	function change_vc_row() {
		$args = array(
			array(
				"type"        => "checkbox",
				"group"       => "Additions",
				"holder"      => "div",
				"class"       => "custom-checkbox",
				"heading"     => esc_html__( 'Parallax effect: ', 'cize' ),
				"description" => esc_html__( 'Chosen for using Paralax scroll', 'cize' ),
				"param_name"  => "paralax_class",
				'admin_label' => true,
				"value"       => array(
					esc_html__( 'paralax-slide', 'cize' ) => "type_paralax",
				),
			),
			array(
				"type"        => "checkbox",
				"group"       => "Additions",
				"heading"     => esc_html__( 'Slide Class: ', 'cize' ),
				"description" => esc_html__( 'Chosen for using slide scroll', 'cize' ),
				"param_name"  => "section_class",
				'admin_label' => true,
				"value"       => array(
					esc_html__( 'section-slide', 'cize' ) => "section-slide",
				),
			),
		);
		foreach ( $args as $value ) {
			// vc_add_param( "vc_row", $value );
			vc_add_param( "vc_section", $value );
		}
	}

	change_vc_row();
	get_template_part( 'vc_templates/vc_row.php' );
	get_template_part( 'vc_templates/vc_section.php' );
}

VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Accordion' );

class WPBakeryShortCode_Cize_Tabs extends WPBakeryShortCode_VC_Tta_Accordion {
}

class WPBakeryShortCode_Cize_Accordions extends WPBakeryShortCode_VC_Tta_Accordion {
}

class WPBakeryShortCode_Cize_Container extends WPBakeryShortCodesContainer {
}

class WPBakeryShortCode_Cize_Slider extends WPBakeryShortCodesContainer {
}

class WPBakeryShortCode_cize_Instagramshopwrap extends WPBakeryShortCodesContainer {
}
