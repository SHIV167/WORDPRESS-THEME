<?php
/*
     Name: Product style 02
     Slug: content-product-style-02
*/

$args = isset($args) ? $args : null;
remove_action('woocommerce_before_shop_loop_item_title', 'cize_group_flash', 5);
remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 15);
?>
    <div class="product-inner">
        <div class="product-info">
            <?php
            /**
             * woocommerce_after_shop_loop_item_title hook.
             *
             * @hooked woocommerce_template_loop_rating - 5
             * @hooked woocommerce_template_loop_price - 10
             */
            do_action('woocommerce_after_shop_loop_item_title');
            do_action('cize_custom_save_flash'); ?>
        </div>
    </div>
<?php
add_action('woocommerce_before_shop_loop_item_title', 'cize_group_flash', 5);
add_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 15);